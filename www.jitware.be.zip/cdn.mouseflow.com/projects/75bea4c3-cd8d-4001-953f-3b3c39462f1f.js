var mouseflowDisableKeyLogging = true;
if (typeof mouseflow === 'undefined' && typeof mouseflowPlayback === 'undefined') {
    (function() {
        var _228 = false;
        var _202 = false;
        var _227 = [];
        var _230 = [];
        var _18 = 'https://eu.mouseflow.com';
        var _206 = false;
        var _217 = typeof _367 === 'function';

        function _301(_109) {
            return 'MF' + (_5.includeDebugTime ? ' - ' + _184 : '') + ': ' + _109
        }

        function _7(_109, _184) {
            if (!_5.debug) return;
            _184 = (typeof _184 !== 'undefined' ? _184 : '');
            if (_109 instanceof Error) {
                _109.message = _301(_109.message);
                console.error(_109)
            } else {
                console.groupCollapsed(_301(_109));
                console.trace();
                console.groupEnd()
            }
        }
        var _41 = new _422(window, _7);
        var _44 = new _330(window);
        var _6 = new _350(window, Math, JSON, _41);
        var _13 = new _395(_41, _6);
        var _34 = new _294('local', window, _6, _7);
        var _143 = new _294('session', window, _6, _7);
        var _274 = new _419(window);
        var _5 = new _442(window, _34, _143, _228, _202, _206);
        _5._129();
        _5._148 = [];
        _5._231 = [];
        _5._232 = [];
        _5._233 = [];
        _5._470 = [];
        _5._468 = [];
        _5._65 = '75bea4c3-cd8d-4001-953f-3b3c39462f1f';
        _5._467 = true;
        _5._463 = '5242000';
        _5._174('appUrl', _18);
        var _445 = new _418(window, _6, _5, _7);

        function _369(_0, _5, _59, _6, _13, _69, _34) {
            var _18, _65, _7, _32;
            var _182 = 'mf_liveHeatmaps';
            var _16;
            var _153 = [];
            var _73;
            var _169 = false;

            function _37(_154, _100, _152, _93) {
                _65 = _154;
                _18 = _152;
                _7 = _100;
                _169 = window.location.search.indexOf('mf_legacy=1') !== -1 ? true : false;
                _7('Live heatmaps starting');
                _32 = _59._116();
                if (!_32) {
                    _7('Live heatmaps not initiated - could not create root HTML element');
                    return
                }
                if (!_0.opener) {
                    _7('Live heatmaps not initiated - window.opener is missing');
                    return
                }
                if (typeof _93 === 'function') {
                    _93(function() {
                        _103()
                    })
                } else {
                    _103()
                }
            }

            function _64() {
                _179()
            }

            function _103() {
                _13._17(_0, 'message', function(_27) {
                    if (_27.origin !== _18) return;
                    _150(_27.data);
                    switch (_27.data.message) {
                        case 'MouseflowLiveHeatmaps_Init_Received':
                            _0.clearInterval(_73);
                            break;
                        case 'MouseflowLiveHeatmaps_Init_Success':
                        case 'MouseflowLiveHeatmaps_Hello':
                            _49(_27.data);
                            _135(_27.data.scripts, function() {
                                var message;
                                if (_169) {
                                    message = {
                                        mfCommand: 'settings',
                                        value: {
                                            websiteSettings: _27.data.websiteSettings
                                        }
                                    }
                                } else {
                                    _255();
                                    message = {
                                        mfCommand: 'settings_liveheatmap',
                                        value: _16
                                    }
                                }
                                _236(JSON.stringify(message))
                            });
                            break;
                        case 'MouseflowLiveHeatmaps_StreamData_Chunk':
                            _137(_27.data.requestUrl, true)._235(_27.data.dataChunk);
                            break;
                        case 'MouseflowLiveHeatmaps_StreamData_Success':
                            _137(_27.data.requestUrl)._81();
                            break;
                        case 'MouseflowLiveHeatmaps_StreamData_Error':
                            _137(_27.data.requestUrl)._107();
                            break;
                        case 'MouseflowLiveHeatmaps_RequestData_Success':
                            _137(_27.data.requestUrl)._81(_27.data.responseText);
                            break;
                        case 'MouseflowLiveHeatmaps_RequestData_Error':
                            _137(_27.data.requestUrl)._107();
                            break
                    }
                });
                _73 = _0.setInterval(_158, 500);
                _0.setTimeout(function() {
                    _0.clearInterval(_73)
                }, 10000);
                _158()
            }

            function _158() {
                _98({
                    message: 'MouseflowLiveHeatmaps_Init',
                    websiteId: _65,
                    legacy: _169
                })
            }

            function _49(_49) {
                _16 = _262();
                var _134 = _260();
                var _161 = _5.location.search.match(/mf_liveHeatmaps=([^&]+)/);
                var _245 = typeof _0.name === 'string' && _0.name.indexOf('mf_liveHeatmaps') === 0 ? _0.name.slice(15).split('_') : [];
                var _403 = _161 || _245[1] === 'init';
                if (_16 && !_403) {
                    _16.filters.url = _134.url;
                    _38(_16);
                    return
                }
                _16 = {
                    isMinimized: false,
                    appUrlBase: _18,
                    websiteId: _65,
                    filters: _134,
                    minDate: _49.minDate,
                    filteredViews: _49.filteredViews,
                    user: _49.user,
                    website: _49.website,
                    mutedEvents: _49.mutedEvents,
                    muteAvailable: _49.muteAvailable,
                    supportedLanguages: _49.supportedLanguages
                };
                if (_49.filters && _49.filters.view) {
                    _16.selectedFilteredView = _49.filters.view;
                    delete _49.filters.view
                }
                if (_49.filters) {
                    Object.keys(_49.filters).forEach(function(_11) {
                        var _8 = _49.filters[_11];
                        if (_8 instanceof Date) _8 = _171(_8);
                        _16.filters[_11] = _8
                    })
                }
                if (_161 && _161[1] !== '1') _16.filters.maptype = _161[1];
                else if (_245[2]) _16.filters.maptype = _245[2];
                _38(_16);
                _0.name = 'mf_liveHeatmaps'
            }

            function _255() {
                _16.devices = _16.filters.device ? _16.filters.device.and || _16.filters.device.or : [];
                _16.mapType = _16.filters.maptype;
                _16.url = _16.filters.url = _69._131();
                _98({
                    message: 'MouseflowLiveHeatmaps_SetSettings',
                    settings: _16
                })
            }

            function _135(_84, _78) {
                if (!_84) return;
                var _101 = 0;

                function _157() {
                    if (_101 >= _84.length) {
                        _78();
                        return
                    }
                    var _33 = _84[_101];
                    _213(_33);
                    _101++;
                    var _88 = document.createElement('script');
                    if (_33.startsWith('/')) _88.src = _18 + _33;
                    else _88.src = _18 + '/' + _33;
                    _88.onload = _157;
                    _32.appendChild(_88)
                }
                _157()
            }

            function _262() {
                return _34._212(_182)
            }

            function _38(_16) {
                if (_7) _7('Live heatmaps saving settings');
                _34._216(_182, _16)
            }

            function _179() {
                if (_7) _7('Live heatmaps removing settings');
                _34._218(_182)
            }

            function _137(_31, _436) {
                var _243 = _153.filter(function(_433) {
                    return _433._31 === _31
                })[0];
                if (!_436 && _243) _153.splice(_153.indexOf(_243), 1);
                return _243
            }

            function _348(_46) {
                if (typeof _46 !== 'object') return;
                _16 = _262();
                var _134 = _260();
                Object.keys(_46).forEach(function(_11) {
                    var _8 = _46[_11];
                    if (_8 instanceof Date) _8 = _171(_8);
                    _16.filters[_11] = _8 || undefined
                });
                Object.keys(_134).forEach(function(_11) {
                    if (!_16.filters[_11]) _16.filters[_11] = _134[_11]
                });
                if (_16.filters.view) {
                    _16.selectedFilteredView = _16.filters.view;
                    delete _16.filters.view
                }
                _38(_16)
            }

            function _260() {
                var _121 = new Date();
                _121 = new Date(_121.getFullYear(), _121.getMonth(), _121.getDate());
                var _237 = new Date(_121);
                _237.setDate(_237.getDate() - 29);
                return {
                    maptype: 'click',
                    url: _69._131(),
                    fromdate: _171(_237),
                    todate: _171(_121)
                }
            }

            function _98(_15) {
                _0.opener.postMessage(_15, _18);
                _7('Sent ' + _15.message + (_15.requestUrl ? ', request URL: ' + _15.requestUrl : ''))
            }

            function _236(_15) {
                _0.postMessage(_15, _0.location.origin);
                _7('Sent ' + _15.message + (_15.requestUrl ? ', request URL: ' + _15.requestUrl : ''))
            }

            function _150(_15) {
                if (_15.message && _15.message.indexOf('MouseflowLiveHeatmaps_') === 0) _7('Received ' + _15.message + (_15.requestUrl ? ', request URL: ' + _15.requestUrl : ''))
            }

            function _213(_33) {
                _7('Live heatmaps loading script: ' + _33)
            }

            function _171(_114) {
                return _114.getFullYear() + '-' + _258(_114.getMonth() + 1, '00') + '-' + _258(_114.getDate(), '00')
            }

            function _258(_341, _257) {
                return (_257 + _341).slice(-_257.length)
            }
            this._37 = _37;
            this._64 = _64;
            this._219 = function(_46) {
                _348(_46);
                if (_169) {
                    _236('{"mfCommand":"MouseflowHeatmap_UpdateHeatmap"}')
                } else {
                    _255();
                    var message = {
                        mfCommand: 'settings_change',
                        value: {
                            settings: _16,
                            reloadData: _46 && _46.maptype ? false : true
                        }
                    };
                    _236(JSON.stringify(message))
                }
                _7('Sent postmessage updateheatmap')
            };
            _0.mouseflowHeatmap = {
                streamData: function(_31, _235, _81, _107) {
                    _153.push({
                        _31: _31,
                        _235: _235 || function() {},
                        _81: _81 || function() {},
                        _107: _107 || function() {}
                    });
                    _98({
                        message: 'MouseflowLiveHeatmaps_StreamData',
                        requestUrl: _31
                    })
                },
                getData: function(_31, _81, _107) {
                    _153.push({
                        _31: _31,
                        _81: _81 || function() {},
                        _107: _107 || function() {}
                    });
                    _98({
                        message: 'MouseflowLiveHeatmaps_RequestData',
                        requestUrl: _31
                    })
                }
            }
        }

        function _383(_0, _5, _59, _6, _13, _69, _34) {
            const _182 = 'mf_liveHeatmaps';
            let _18, _65, _7, _32;
            let _73;
            const _12 = _0.document;
            const _439 = _0.location.search.slice(1).split('&').map(a => a.split('=', 2)).filter(a => a[0]).reduce((acc, cur) => (acc[cur[0]] = cur[1] ? ? null, acc), {});

            function _37(_154, _100, _152, _93) {
                _65 = _154;
                _18 = _152;
                _7 = _100;
                _7('Live heatmaps starting');
                _32 = _59._116();
                if (!_32) {
                    _7('Live heatmaps not initiated - could not create root HTML element');
                    return
                }
                if (!_0.opener) {
                    _7('Live heatmaps not initiated - window.opener is missing');
                    return
                }
                if (typeof _93 === 'function') {
                    _93(function() {
                        _103()
                    })
                } else {
                    _103()
                }
            }

            function _64() {}

            function _103() {
                _13._17(_0, 'message', function(_27) {
                    if (_27.origin !== _18) return;
                    _150(_27.data);
                    switch (_27.data.message) {
                        case 'MouseflowLiveHeatmapsV3_Init_Received':
                            _0.clearInterval(_73);
                            break;
                        case 'MouseflowLiveHeatmapsV3_Init_Success':
                            _135(_27.data.scripts);
                            break
                    }
                });
                _73 = _0.setInterval(_158, 500);
                _0.setTimeout(function() {
                    _0.clearInterval(_73)
                }, 10000);
                _158()
            }

            function _158() {
                _98({
                    message: 'MouseflowLiveHeatmapsV3_Init',
                    websiteId: _65,
                    prod: _439.prod !== undefined
                })
            }

            function _135(_84) {
                for (const _33 of _84) {
                    const _3 = _12.createElement(_33.tagName);
                    if (_33.textContent) {
                        _3.textContent = _33.textContent
                    }
                    for (const _11 in _33.attributes) {
                        const _8 = _33.attributes[_11];
                        if (_11 === 'src' || _11 === 'href') {
                            _3[_11] = _18 + _8
                        } else {
                            _3.setAttribute(_11, _8)
                        }
                    }
                    if (_3.tagName === 'SCRIPT') {
                        _3.async = false
                    }
                    if (_3.tagName === 'SCRIPT' && _3.type === 'importmap') {
                        _3.textContent = _3.textContent.replace(/(:\s*")(\/[^"]+")/g, `$1${_18}$2`)
                    }
                    _32.appendChild(_3)
                }
            }

            function _98(_15) {
                _0.opener.postMessage(_15, _18);
                _7('Sent ' + _15.message + (_15.requestUrl ? ', request URL: ' + _15.requestUrl : ''))
            }

            function _150(_15) {
                if (_15.message && _15.message.indexOf('MouseflowLiveHeatmapsV3_') === 0) _7('Received ' + _15.message + (_15.requestUrl ? ', request URL: ' + _15.requestUrl : ''))
            }
            this._37 = _37;
            this._64 = _64;
            this._219 = function() {
                window.updateSpaPage()
            }
        }

        function _351(_0, _59, _41, _44, _6, _13, _34, _5) {
            var _12 = _0.document,
                _18, _65, _7, _1, _32, _83, _10, _285, _286, _287, _290, _82, _70, _177, _89, _283, _111, _146, _142, _86, _77, _167;

            function _37(_366, _154, _148, _231, _232, _233, _100) {
                _18 = _366;
                _65 = _154;
                _7 = _100;
                _1 = _432() || {
                    _71: false,
                    _28: 'exclude',
                    _39: _148 || [],
                    _40: _231 || [],
                    _56: _232 || [],
                    _61: _233 || []
                };
                _7('Starting privacy tool');
                _32 = _59._116();
                if (!_32) {
                    _7('Privacy tool not initiated - could not create root HTML element');
                    return
                }
                _364();
                _44._97(function() {
                    _362();
                    _38(_1)
                }, 1000);
            }

            function _64() {
                _353();
                if (_83) {
                    _32.removeChild(_83);
                    _83 = null
                }
                if (_10) {
                    _32.removeChild(_10);
                    _10 = null
                }
            }

            function _364() {
                _13._17(_0, 'message', function(event) {
                    if (event.origin !== _18) return;
                    switch (event.data.message) {
                        case 'MouseflowPrivacyTool_Hello':
                            _7('Privacy tool API ready');
                            _142 = event.source;
                            if (event.data.cssSelectorBlacklist) {
                                _1._39 = event.data.cssSelectorBlacklist;
                                _1._40 = event.data.cssSelectorWhitelist;
                                _1._56 = event.data.cssSelectorTracked;
                                _1._61 = event.data.cssSelectorMasked
                            }
                            _129();
                            break;
                        case 'MouseflowPrivacyTool_Save_Success':
                            _7('Successfully saved CSS lists');
                            if (_86) _86();
                            _86 = undefined;
                            _77 = undefined;
                            break;
                        case 'MouseflowPrivacyTool_Save_Failed':
                            _7('Failed saving CSS lists');
                            if (_77) _77();
                            _86 = undefined;
                            _77 = undefined;
                            _207('Uh oh! We couldn\'t save your changes.<br><br>' + 'Please refresh the page and try again.');
                            break;
                        case 'MouseflowPrivacyTool_Unauthorized':
                            _7('Privacy tool API logged out - cannot save');
                            if (_77) _77();
                            _86 = undefined;
                            _77 = undefined;
                            _207('Uh oh! We couldn\'t save your changes.<br><br>' + 'Please log into Mouseflow and try again.');
                            break
                    }
                });
                if (_0.opener) {
                    _7('Loading privacy tool API using window.opener');
                    _0.opener.postMessage({
                        message: 'MouseflowPrivacyTool_Hello'
                    }, _18)
                }
                _44._97(function() {
                    if (!_142) {
                        _7('Loading privacy tool API using iframe');
                        _83 = _12.createElement('iframe');
                        _83.style.width = '0px';
                        _83.style.height = '0px';
                        _83.style.display = 'none';
                        _83.src = _18 + '/websites/' + _65 + '/privacytool';
                        _32.appendChild(_83);
                        _44._97(function() {
                            if (!_142) {
                                _7('Loading privacy tool API timed out');
                                _458('We\'re having trouble loading the Privacy Tool on this page. Please try ' + 'refreshing the page or logging in to Mouseflow and reloading the Privacy Tool from there.<br><br>' + 'If you need help, please don\'t hesitate to reach out to us at:  <a class="green" href="mailto:support@mouseflow.com">support@mouseflow.com</a>')
                            }
                        }, 5000)
                    }
                }, 2000)
            }

            function _362() {
                _10 = _452(_1);
                _285 = _10.querySelector('.tool-exclude output');
                _286 = _10.querySelector('.tool-whitelist output');
                _287 = _10.querySelector('.tool-track output');
                _290 = _10.querySelector('.tool-masked output');
                _82 = _10.querySelector('.tool-status-text');
                _70 = _10.querySelector('.btn-widget');
                _177 = _10.querySelector('.tool-loading h2');
                _1._39.forEach(_277);
                _1._40.forEach(_275);
                _1._56.forEach(_278);
                _1._61.forEach(_273);
                _32.appendChild(_10);
                _89 = _450();
                _10.appendChild(_89);
                _6._136(_12.body, 'mf-privacy-tool-opened', !_1._71);
                _361();
                _129()
            }

            function _129() {
                if (_10 && _142) {
                    _6._30(_10, 'is-loading');
                    _67();
                    _360();
                    _183()
                }
            }

            function _234() {
                _179();
                _64();
                _0.close()
            }

            function _361() {
                _13._17(_10, 'click', '.mf-tool-close', _234, {
                    _47: true
                })
            }

            function _360() {
                _13._17(_10, 'click', '.mf-tool-toggle', _291, {
                    _47: true
                });
                _13._17(_10, 'click', '.mf-tool-close', _234, {
                    _47: true
                });
                _13._17(_10, 'click', '.mf-tool-exclude', _370, {
                    _47: true
                });
                _13._17(_10, 'click', '.mf-tool-whitelist', _386, {
                    _47: true
                });
                _13._17(_10, 'click', '.mf-tool-track', _385, {
                    _47: true
                });
                _13._17(_10, 'click', '.mf-tool-masked', _384, {
                    _47: true
                });
                _13._17(_10, 'click', '.highlight-excluded', _382, {
                    _47: true
                });
                _13._17(_10, 'click', '.highlight-whitelisted', _381, {
                    _47: true
                });
                _13._17(_10, 'click', '.highlight-tracked', _380, {
                    _47: true
                });
                _13._17(_10, 'click', '.highlight-masked', _387, {
                    _47: true
                });
                _13._17(_10, 'click', '.mf-remove-excluded', _379, {
                    _47: true
                });
                _13._17(_10, 'click', '.mf-remove-whitelisted', _377, {
                    _47: true
                });
                _13._17(_10, 'click', '.mf-remove-tracked', _376, {
                    _47: true
                });
                _13._17(_10, 'click', '.mf-remove-masked', _375, {
                    _47: true
                });
                _13._17(_10, 'submit', _374, {
                    _47: true
                });
                _13._17(_12, 'mouseover', _372, {
                    _52: true
                });
                _13._17(_12, 'mouseleave', _371, {
                    _52: true
                });
                _13._17(_12, 'mouseup', _378, {
                    _52: true
                });
                _13._17(_12, 'mouseenter', _91, {
                    _52: true
                });
                _13._17(_12, 'mousemove', _91, {
                    _52: true
                });
                _13._17(_12, 'mousedown', _91, {
                    _52: true
                });
                _13._17(_12, 'click', _91, {
                    _52: true
                });
                _13._17(_12, 'mouseout', _91, {
                    _52: true
                });
                _13._17(_12, 'scroll', _67, {
                    _52: true,
                    _225: true
                });
                _13._17(_0, 'resize', _67, {
                    _52: true,
                    _225: true
                });
                var MutationObserver = _0.MutationObserver || _0.WebKitMutationObserver || _0.MozMutationObserver;
                if (MutationObserver) {
                    _146 = new MutationObserver(function(_246) {
                        var _356 = _246.some(function(_85) {
                            if (_85.target.nodeType !== 1 || _6._42(_85.target, '#mouseflow *')) return false;
                            var _359 = _85.oldValue && _85.oldValue.indexOf('mf-highlight') !== -1;
                            var _358 = _85.target.classList.contains('mf-highlight');
                            var _357 = _359 || _358;
                            if (_85.type === 'attributes' && _85.attributeName === 'class' && _357) return false;
                            return true
                        });
                        if (_356) _67();
                        _246.forEach(function(_85) {
                            _85.addedNodes.forEach(function(_240) {
                                if (!_240.shadowRoot) return;
                                _146.observe(_240.shadowRoot, {
                                    childList: true,
                                    subtree: true
                                });
                                _183(_240)
                            })
                        })
                    });
                    _146.observe(_12, {
                        attributes: true,
                        childList: true,
                        characterData: true,
                        subtree: true,
                        attributeOldValue: true
                    })
                }
            }

            function _353() {
                _13._443();
                if (_146) _146.disconnect()
            }

            function _183(_79) {
                if (!_167) _167 = _393();
                if (!_79) _79 = _12;
                for (var _149 = _41._453(_79); _149; _149 = _41._459(_149)) {
                    _183(_149);
                    var _76 = _149.shadowRoot;
                    if (!_76) continue;
                    _183(_76);
                    if (_76.adoptedStyleSheets) {
                        if (_76.adoptedStyleSheets.indexOf(_167) > -1) continue;
                        var _289 = Array.prototype.slice.call(_76.adoptedStyleSheets);
                        _289.push(_167);
                        _76.adoptedStyleSheets = _289
                    } else {
                        if (_76.querySelector('.mf-privacy-tool-style')) continue;
                        var _92 = _12.createElement('style');
                        _92.type = 'text/css';
                        _92.innerHTML = _221();
                        _92.className = 'mf-privacy-tool-style';
                        _76.appendChild(_92)
                    }
                }
            }

            function _291() {
                _1._71 = !_1._71;
                _38(_1);
                _6._136(_10, 'tool-closed', _1._71);
                _6._136(_12.body, 'mf-privacy-tool-opened', !_1._71);
                var _162 = _10.getElementsByClassName('step')[0];
                var _163 = _10.getElementsByClassName('tool-container')[0];
                if (_1._71) {
                    _6._30(_162, 'fade-out');
                    _6._54(_162, 'fade-in');
                    _6._30(_163, 'fade-in');
                    _6._54(_163, 'fade-out')
                } else {
                    _6._30(_162, 'fade-in');
                    _6._54(_162, 'fade-out');
                    _6._30(_163, 'fade-out');
                    _6._54(_163, 'fade-in')
                }
            }

            function _370() {
                _1._28 = 'exclude';
                _38(_1);
                _168()
            }

            function _386() {
                _1._28 = 'whitelist';
                _38(_1);
                _168()
            }

            function _385() {
                _1._28 = 'track';
                _38(_1);
                _168()
            }

            function _384() {
                _1._28 = 'masked';
                _38(_1);
                _168()
            }

            function _168() {
                _6._30(_10.getElementsByClassName('mf-tool-exclude')[0], 'active');
                _6._30(_10.getElementsByClassName('tool-exclude')[0], 'active');
                _6._30(_10.getElementsByClassName('mf-tool-whitelist')[0], 'active');
                _6._30(_10.getElementsByClassName('tool-whitelist')[0], 'active');
                _6._30(_10.getElementsByClassName('mf-tool-track')[0], 'active');
                _6._30(_10.getElementsByClassName('tool-track')[0], 'active');
                _6._30(_10.getElementsByClassName('mf-tool-masked')[0], 'active');
                _6._30(_10.getElementsByClassName('tool-masked')[0], 'active');
                _6._54(_10.getElementsByClassName('mf-tool-' + _1._28)[0], 'active');
                _6._54(_10.getElementsByClassName('tool-' + _1._28)[0], 'active')
            }

            function _382(_9) {
                if (_1._28 === 'exclude') {
                    _272(_9.target.getAttribute('data-target'));
                    _67()
                }
            }

            function _381(_9) {
                if (_1._28 === 'whitelist') {
                    _271(_9.target.getAttribute('data-target'));
                    _67()
                }
            }

            function _380(_9) {
                if (_1._28 === 'track') {
                    _270(_9.target.getAttribute('data-target'));
                    _67()
                }
            }

            function _387(_9) {
                if (_1._28 === 'masked') {
                    _269(_9.target.getAttribute('data-target'));
                    _67()
                }
            }

            function _379(_9) {
                _272(_9.target.parentNode.getAttribute('data-target'));
                _67()
            }

            function _377(_9) {
                _271(_9.target.parentNode.getAttribute('data-target'));
                _67()
            }

            function _376(_9) {
                _270(_9.target.parentNode.getAttribute('data-target'));
                _67()
            }

            function _375(_9) {
                _269(_9.target.parentNode.getAttribute('data-target'));
                _67()
            }

            function _374() {
                _435();
                _345(_1._39, _1._40, _1._56, _1._61, function() {
                    _284();
                    _70.innerHTML = 'Saved';
                    _179();
                    _44._97(_234, 500)
                }, function() {
                    _284()
                })
            }

            function _372(_9) {
                _44._239(_283);
                var _288 = _12.getElementsByClassName('mf-highlight');
                for (var _4 = 0; _4 < _288.length; _4++) {
                    _6._30(_288[_4], 'mf-highlight')
                }
                _6._54(_89, 'hidden');
                if (_91(_9) || _293(_9.target)) return;
                _6._54(_9.target, 'mf-highlight');
                _283 = _44._97(function() {
                    var _25 = _9.target.getBoundingClientRect();
                    _89.style.left = _25.left + _0.pageXOffset + 'px';
                    _89.style.top = _25.top + _0.pageYOffset + 'px';
                    _89.style.width = _25.width + 'px';
                    _89.style.height = _25.height + 'px';
                    _6._30(_89, 'hidden')
                }, 75)
            }

            function _371(_9) {
                if (_91(_9)) return;
                if (_9.target === _12) {
                    _6._54(_89, 'hidden')
                }
            }

            function _378(_9) {
                if (_91(_9)) return;
                if (_9.button !== 0 || _293(_9.target)) return;
                _6._30(_9.target, 'mf-highlight');
                var _2 = _336(_9.target);
                if (_1._28 === 'exclude') {
                    _277(_2)
                } else if (_1._28 === 'whitelist') {
                    _275(_2)
                } else if (_1._28 === 'masked') {
                    _273(_2)
                } else {
                    _278(_2)
                }
                _67()
            }

            function _91(_9) {
                if (_1._71 || _9.target.nodeType !== 1 || _6._42(_9.target, '#mouseflow *')) return true;
                _9.preventDefault();
                _9.stopPropagation();
                return false
            }

            function _293(_3) {
                return _3 === _12.body || _6._42(_3, 'html') || (_1._28 === 'whitelist' && (!/INPUT|TEXTAREA/.test(_3.tagName) || /checkbox|radio|button|submit/.test(_3.type)))
            }

            function _278(_2) {
                if (_2 && _1._56.indexOf(_2) === -1) {
                    _1._56.unshift(_2);
                    _38(_1)
                }
                _94()
            }

            function _277(_2) {
                if (_2 && _1._39.indexOf(_2) === -1) {
                    _1._39.unshift(_2);
                    _38(_1)
                }
                _94()
            }

            function _275(_2) {
                if (_2 && _1._40.indexOf(_2) === -1) {
                    _1._40.unshift(_2);
                    _38(_1)
                }
                _94()
            }

            function _273(_2) {
                if (_2 && _1._61.indexOf(_2) === -1) {
                    _1._61.unshift(_2);
                    _38(_1)
                }
                _94()
            }

            function _272(_2) {
                if (_2 && _1._39.indexOf(_2) !== -1) {
                    _1._39 = _1._39.filter(function(_110) {
                        return _110 !== _2
                    });
                    _38(_1)
                }
                _94()
            }

            function _271(_2) {
                if (_2 && _1._40.indexOf(_2) !== -1) {
                    _1._40 = _1._40.filter(function(_110) {
                        return _110 !== _2
                    });
                    _38(_1)
                }
                _94()
            }

            function _270(_2) {
                if (_2 && _1._56.indexOf(_2) !== -1) {
                    _1._56 = _1._56.filter(function(_110) {
                        return _110 !== _2
                    });
                    _38(_1)
                }
                _94()
            }

            function _269(_2) {
                if (_2 && _1._61.indexOf(_2) !== -1) {
                    _1._61 = _1._61.filter(function(_110) {
                        return _110 !== _2
                    });
                    _38(_1)
                }
                _94()
            }

            function _67() {
                _44._239(_111);
                if (!_111) {
                    _44._97(function() {
                        if (_111) {
                            _44._239(_111);
                            _268();
                            _111 = undefined
                        }
                    }, 200)
                }
                _111 = _44._97(function() {
                    _268();
                    _111 = undefined
                }, 100)
            }

            function _268() {
                var _265 = _10.querySelectorAll('.highlight-excluded,.highlight-whitelisted,.highlight-tracked,.highlight-masked'),
                    _4;
                for (_4 = 0; _4 < _265.length; _4++) {
                    _10.removeChild(_265[_4])
                }
                _1._39.forEach(function(_2) {
                    var _58 = _144(_2, _12);
                    for (_4 = 0; _4 < _58.length; _4++) {
                        _10.appendChild(_449(_2, _58[_4].getBoundingClientRect()))
                    }
                });
                _1._40.forEach(function(_2) {
                    var _58 = _144(_2, _12);
                    for (_4 = 0; _4 < _58.length; _4++) {
                        _10.appendChild(_448(_2, _58[_4].getBoundingClientRect()))
                    }
                });
                _1._56.forEach(function(_2) {
                    var _58 = _144(_2, _12);
                    for (_4 = 0; _4 < _58.length; _4++) {
                        _10.appendChild(_447(_2, _58[_4].getBoundingClientRect()))
                    }
                });
                _1._61.forEach(function(_2) {
                    var _58 = _144(_2, _12);
                    for (_4 = 0; _4 < _58.length; _4++) {
                        _10.appendChild(_428(_2, _58[_4].getBoundingClientRect()))
                    }
                })
            }

            function _144(_2, _24) {
                try {
                    var _58 = [];
                    _2.split(',').forEach(function(_2) {
                        var _19 = _2.split(' > :document-fragment: > ', 1);
                        _24.querySelectorAll(_19[0]).forEach(function(_3) {
                            if (_19[1] && _3.shadowRoot) {
                                _144(_19[1], _3.shadowRoot).forEach(function(_3) {
                                    _58.push(_3)
                                })
                            } else {
                                _58.push(_3)
                            }
                        })
                    });
                    return _58
                } catch (_490) {
                    _7('Could not get element from selector: ' + ex.message)
                }
            }

            function _345(_39, _40, _56, _61, _81, _346) {
                if (_86) {
                    _7('Attempted to save CSS lists while previous save was in progress');
                    return
                }
                _86 = _81;
                _77 = _346;
                _454();
                _142.postMessage({
                    message: 'MouseflowPrivacyTool_Save',
                    blacklist: _39,
                    whitelist: _40,
                    tracked: _56,
                    masked: _61
                }, _18);
                _44._97(function() {
                    if (_86 === _81) {
                        _7('Saving CSS lists timed out');
                        if (_77) _77();
                        _86 = undefined;
                        _77 = undefined;
                        _207('Uh oh! We couldn\'t save your changes.<br><br>' + 'Please log into Mouseflow and try again.')
                    }
                }, 7500)
            }

            function _336(_3) {
                if (_3 == null) return null;
                try {
                    var _140 = [];
                    while (_3) {
                        var _24 = _3.getRootNode ? _3.getRootNode() : _12;
                        var _2 = _267(_3, _24);
                        _140.unshift(_2);
                        _3 = _24.host
                    }
                    return _140.join(' > :document-fragment: > ')
                } catch (ex) {
                    _7('Could not get element selector: ' + ex.message);
                    return null
                }
            }

            function _471(_3, _24) {
                var _141 = _332(_3, _24);
                if (!_141) return null;
                if (_6._42(_3, _141)) return _141;
                var _59 = _24.querySelector(_141);
                var _72 = _3;
                var _19 = [];
                while (_72 && _72 !== _59) {
                    var _26 = _205(_72, _24);
                    if (_26.length === 0) _26.push(_276(_72));
                    _19.unshift(_26);
                    _72 = _72.parentNode
                }
                _19.unshift(_141);
                return _197(_19, _24)
            }

            function _267(_3, _24, _19) {
                if (!_19) _19 = [];
                var _26 = _205(_3, _24);
                _19.unshift(_26);
                var _2 = _197(_19, _24);
                if (_2) return _2;
                if (_26.length === 0) {
                    _26.push(_276(_3));
                    _2 = _197(_19, _24);
                    if (_2) return _2
                }
                return _267(_3.parentNode, _24, _19)
            }

            function _197(_19, _24) {
                var _200 = _19.length > 1 ? _441.apply(this, _19) : _19[0];
                for (var _4 = 0; _4 < _200.length; _4++) {
                    if (_24.querySelectorAll(_200[_4]).length === 1) return _200[_4]
                }
                return null
            }

            function _332(_3, _24) {
                var _72 = _3;
                while (_72) {
                    var _26 = _205(_72, _24);
                    for (var _4 = 0; _4 < _26.length; _4++) {
                        if (_24.querySelectorAll(_26[_4]).length === 1) return _26[_4]
                    }
                    _72 = _72.parentNode
                }
                return null
            }

            function _205(_3, _24) {
                if (_3 === _12.body) return ['body'];
                var _26 = [];
                var _79 = _3.parentNode;
                var _4;
                var _140 = _3.getAttribute('id');
                var _2 = '#' + _6._95(_140);
                if (_140 && _24.querySelectorAll(_2).length === 1 && !_6._214(_3, 'data-mf-ignore-child-ids') && _5.useIdSelectors) return [_2];
                var _66 = _3.getAttribute('name');
                _2 = '[name="' + _6._95(_66) + '"]';
                if (_66) {
                    if (_24.querySelectorAll(_2).length === 1) return [_2];
                    if (_79.querySelectorAll(_2).length === 1) _26.push(_2)
                }
                var _74 = _6._120(_3);
                for (_4 = 0; _4 < _74.length; _4++) {
                    _2 = '.' + _6._95(_74[_4]);
                    if (_24.querySelectorAll(_2).length === 1) return [_2];
                    if (_79.querySelectorAll(_2).length === 1) _26.push(_2)
                }
                for (_4 = 0; _4 < _74.length; _4++) {
                    _2 = _6._95(_3.tagName.toLowerCase()) + '.' + _6._95(_74[_4]);
                    if (_24.querySelectorAll(_2).length === 1) return [_2];
                    if (_79.querySelectorAll(_2).length === 1) _26.push(_2)
                }
                return _26
            }

            function _276(_3) {
                var _2 = _6._95(_3.tagName.toLowerCase());
                if (_3.parentNode.querySelectorAll(_2).length === 1) return _2;
                var _280 = 0;
                var _173 = _3;
                while (_173) {
                    if (_173.tagName === _3.tagName) _280++;
                    _173 = _173.previousElementSibling
                }
                _2 += ':nth-of-type(' + _280 + ')';
                return _2
            }

            function _441() {
                var _26, _132, _130, _4;
                var _138 = 0;
                var _113 = arguments.length - 1;
                var _176 = false;
                var _133 = true;
                while (_138 < _113) {
                    _132 = undefined;
                    for (_4 = 0; _4 <= _138; _4++) {
                        _132 = _132 ? _180(_132, arguments[_4], ' > ') : arguments[_4]
                    }
                    _130 = undefined;
                    for (_4 = arguments.length - 1; _4 >= _113; _4--) {
                        _130 = _130 ? _180(arguments[_4], _130, ' > ') : arguments[_4]
                    }
                    var _181 = (_138 + 1) == _113 ? ' > ' : ' ';
                    _26 = _26 ? _26.concat(_180(_132, _130, _181)) : _180(_132, _130, _181);
                    if (_133 && _176) {
                        _113--;
                        _176 = false;
                        _133 = true
                    } else if (_133) {
                        _113--;
                        _176 = true;
                        _133 = false
                    } else {
                        _138++;
                        if (_138 != _113) _113++;
                        _176 = true;
                        _133 = true
                    }
                }
                return _26
            }

            function _180(_281, _282, _181) {
                var _26 = [];
                for (var _4 = 0; _4 < _281.length; _4++) {
                    for (var _195 = 0; _195 < _282.length; _195++) {
                        _26.push(_281[_4] + _181 + _282[_195])
                    }
                }
                return _26
            }

            function _432() {
                return _34._212('mf_privacyTool') || null
            }

            function _38(_16) {
                _34._216('mf_privacyTool', _16)
            }

            function _179() {
                _34._218('mf_privacyTool')
            }

            function _435() {
                _70.setAttribute('disabled', '');
                _70.setAttribute('original-html', _70.innerHTML);
                _70.innerHTML = '<i>&bull;</i> <i>&bull;</i> <i>&bull;</i> <i>&bull;</i>';
                _6._54(_70, 'loading')
            }

            function _284() {
                _6._30(_70, 'loading');
                _70.innerHTML = _70.getAttribute('original-html');
                _70.removeAttribute('original-html');
                _70.removeAttribute('disabled')
            }

            function _94() {
                _285.innerHTML = _400(_1._39);
                _286.innerHTML = _399(_1._40);
                _287.innerHTML = _398(_1._56);
                _290.innerHTML = _397(_1._61);
                _82.innerHTML = _222(_1._39, _1._40, _1._56, _1._61);
                _6._30(_82, 'red')
            }

            function _458(_108) {
                if (!_177) return;
                if (_1._71) _291();
                _177.innerHTML = _108;
                _6._54(_177, 'red')
            }

            function _207(_108) {
                if (!_82) return;
                _82.innerHTML = _108;
                _6._54(_82, 'red')
            }

            function _454() {
                if (!_82) return;
                _82.innerHTML = _222(_1._39, _1._40, _1._56, _1._61);
                _6._30(_82, 'red')
            }

            function _452(_1) {
                var _14 = _12.createElement('div');
                _14.className = 'privacy-tool is-loading';
                _14.innerHTML = _426(_1);
                if (_1._71) _14.className += ' tool-closed';
                var _92 = _12.createElement('style');
                _92.type = 'text/css';
                _92.innerHTML = _221();
                _14.appendChild(_92);
                return _14
            }

            function _450() {
                var _14 = _12.createElement('div');
                _14.className = 'highlight-box';
                return _14
            }

            function _449(_2, _25) {
                var _14 = _12.createElement('div');
                _14.className = 'highlight-box highlight-excluded';
                _14.setAttribute('data-target', _2);
                _14.style.left = _25.left + _0.pageXOffset + 'px';
                _14.style.top = _25.top + _0.pageYOffset + 'px';
                _14.style.width = _25.width + 'px';
                _14.style.height = _25.height + 'px';
                return _14
            }

            function _448(_2, _25) {
                var _14 = _12.createElement('div');
                _14.className = 'highlight-box highlight-whitelisted';
                _14.setAttribute('data-target', _2);
                _14.style.left = _25.left + _0.pageXOffset + 'px';
                _14.style.top = _25.top + _0.pageYOffset + 'px';
                _14.style.width = _25.width + 'px';
                _14.style.height = _25.height + 'px';
                return _14
            }

            function _447(_2, _25) {
                var _14 = _12.createElement('div');
                _14.className = 'highlight-box highlight-tracked';
                _14.setAttribute('data-target', _2);
                _14.style.left = _25.left + _0.pageXOffset + 'px';
                _14.style.top = _25.top + _0.pageYOffset + 'px';
                _14.style.width = _25.width + 'px';
                _14.style.height = _25.height + 'px';
                return _14
            }

            function _428(_2, _25) {
                var _14 = _12.createElement('div');
                _14.className = 'highlight-box highlight-masked';
                _14.setAttribute('data-target', _2);
                _14.style.left = _25.left + _0.pageXOffset + 'px';
                _14.style.top = _25.top + _0.pageYOffset + 'px';
                _14.style.width = _25.width + 'px';
                _14.style.height = _25.height + 'px';
                return _14
            }

            function _426(_1) {
                return ('<form action="#" id="mf_privacy_tool">' + _407(_1) + _427(_1) + '</form>')
            }

            function _407(_1) {
                return ('<div class="step step-block' + (_1._71 ? ' fade-in' : '') + '">' + '<div class="widget-header">' + '<div class="widget-text">Open privacy tool</div>' + '<div class="widget-toggle">' + '<a href="#" class="btn-arrow btn-arrow--up mf-tool-toggle"></a>' + '</div>' + '</div>' + '</div>')
            }

            function _427() {
                return ('<div class="tool-container' + (_1._71 ? '' : ' fade-in') + '">' + '<div class="tool-header">' + '<div class="tool-title">' + '<svg class="logo" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="37" height="34" viewBox="0 0 37 34"><g id="logomark_dark" transform="translate(0 0.281)"><path id="Path_7123" class="logo-path" data-name="Path 7123" d="M36.916,16.723c0-2.879-2.308-5.423-6.032-7.173.347-4.1-.708-7.367-3.2-8.812S21.832.029,18.452,2.378c-.111-.078-.218-.153-.329-.227-3.4-2.267-6.552-2.768-8.9-1.417C6.735,2.171,5.685,5.444,6.034,9.547,2.308,11.3,0,13.844,0,16.723S2.311,22.149,6.038,23.9c-.013.133-.023.268-.03.4-.268,4.069.878,7.057,3.219,8.408a5.667,5.667,0,0,0,2.877.738,11.533,11.533,0,0,0,6.353-2.379,11.533,11.533,0,0,0,6.353,2.379,5.687,5.687,0,0,0,2.877-.738c2.343-1.352,3.485-4.339,3.222-8.408-.009-.133-.018-.268-.031-.4C34.607,22.149,36.916,19.6,36.916,16.723Zm-12.09-14.7a3.668,3.668,0,0,1,1.855.455c1.548.894,2.363,3.181,2.233,6.268a28.258,28.258,0,0,0-5.13-1.254,27.937,27.937,0,0,0-3.652-3.81A9.132,9.132,0,0,1,24.826,2.024ZM8.217,10.82a24.675,24.675,0,0,1,3.168-.941c-.432.652-.85,1.329-1.261,2.03s-.788,1.417-1.133,2.125a23.11,23.11,0,0,1-.774-3.215ZM22.7,24.077a34.406,34.406,0,0,1-4.243.256,34.365,34.365,0,0,1-4.242-.256c-.992-.123-1.928-.29-2.816-.492a23.143,23.143,0,0,1-3.174-.946,23.7,23.7,0,0,1,.765-3.222c.275-.885.6-1.785.982-2.692a33.8,33.8,0,0,1,1.9-3.811A34.244,34.244,0,0,1,14.2,9.381q.908-1.2,1.842-2.206A23.422,23.422,0,0,1,18.453,4.9a23.659,23.659,0,0,1,2.408,2.278A27.591,27.591,0,0,1,22.7,9.381a34.1,34.1,0,0,1,2.343,3.533,34.039,34.039,0,0,1,1.9,3.811,28.251,28.251,0,0,1,.982,2.692,23.66,23.66,0,0,1,.769,3.225,23.235,23.235,0,0,1-3.179.946C24.626,23.785,23.688,23.952,22.7,24.077Zm-4.243,2.267c.82,0,1.626-.027,2.408-.078a23.788,23.788,0,0,1-2.408,2.281,23.478,23.478,0,0,1-2.408-2.281Q17.228,26.344,18.457,26.344Zm9.468-12.306q-.526-1.071-1.133-2.125T25.53,9.881a24.368,24.368,0,0,1,3.166.939,22.89,22.89,0,0,1-.771,3.219ZM10.235,2.479a3.737,3.737,0,0,1,1.877-.463A9.029,9.029,0,0,1,16.778,3.68a28.033,28.033,0,0,0-3.65,3.812A27.992,27.992,0,0,0,8,8.749C7.866,5.659,8.683,3.373,10.235,2.479ZM2.017,16.723c0-1.928,1.646-3.715,4.31-5.072a27.76,27.76,0,0,0,1.479,5.078,28.156,28.156,0,0,0-1.475,5.066c-2.75-1.429-4.318-3.283-4.318-5.072Zm10.074,14.7a3.684,3.684,0,0,1-1.857-.456C8.661,30.055,7.853,27.78,8,24.7a28.105,28.105,0,0,0,5.122,1.254,28.219,28.219,0,0,0,3.652,3.812A9.118,9.118,0,0,1,12.092,31.42Zm14.592-.456c-1.55.894-3.937.463-6.544-1.2a28.218,28.218,0,0,0,3.652-3.812A28.193,28.193,0,0,0,28.917,24.7c.146,3.081-.662,5.357-2.237,6.265Zm3.909-9.169a28.41,28.41,0,0,0-1.475-5.065A28.321,28.321,0,0,0,30.6,11.651c2.662,1.357,4.308,3.144,4.308,5.072-.007,1.789-1.575,3.642-4.321,5.072Z" transform="translate(0 0)" fill="#0f172f"/><path id="Path_7124" data-name="Path 7124" d="M100,75.4a29.752,29.752,0,0,0-5,10.427l5-2.726,5,2.726A30.653,30.653,0,0,0,100,75.4Z" transform="translate(-81.541 -64.726)" fill="#0f172f"/></g></svg>' + '<h3>Click elements in the interface that you wish to manage</h3>' + '<div class="tool-toggle">' + '<div class="tool-toggle-text">' + '<b> Hide to navigate </b>' + '</div>' + '<div class="tool-toggle-icon">' + '<a href="#" class="btn-arrow btn-arrow--down mf-tool-toggle"></a>' + '</div>' + '</div>' + '<div class="tool-close">' + '<div class="tool-toggle-text">' + 'Close' + '</div>' + '<div class="tool-toggle-icon">' + '<a href="#" class="btn-cross mf-tool-close"></a>' + '</div>' + '</div>' + '</div>' + '</div>' + '<div class="tool-content">' + '<ul class="tool-menu">' + '<li class="tool-menu-item mf-tool-exclude' + (_1._28 === 'exclude' ? ' active' : '') + '">' + 'Excluded content' + '</li>' + '<li class="tool-menu-item mf-tool-masked' + (_1._28 === 'masked' ? ' active' : '') + '">' + 'Masked content' + '</li>' + '<li class="tool-menu-item mf-tool-whitelist' + (_1._28 === 'whitelist' ? ' active' : '') + '">' + 'Whitelisted fields' + '</li>' + '<li class="tool-menu-item mf-tool-track' + (_1._28 === 'track' ? ' active' : '') + '">' + 'Tracked elements' + '</li>' + '</ul>' + '<div class="tool-exclude' + (_1._28 === 'exclude' ? ' active' : '') + '">' + '<h2>Exclude content</h2>' + '<p>' + 'To exclude content from being tracked, click on the element(s) you want to remove. ' + 'The excluded elements and any descendants inside those elements will not be stored or visible in Recordings or Heatmaps.' + 'The CSS selectors of the selected elements will appear in the list below. ' + '</p>' + '<p>' + 'Click "Hide to navigate" to exclude more content or "Save and close" to apply changes. Check our <a href="https://help.mouseflow.com/en/articles/5973120-excluded-whitelisted-tracked-fields" target="_blank">Support Guide</a> for details and best practices.' + '</p>' + '<h3>Excluded content</h3>' + '<div>' + '<output></output>' + '</div>' + '</div>' + '<div class="tool-masked' + (_1._28 === 'masked' ? ' active' : '') + '">' + '<h2>Mask content</h2>' + '<p>' + 'Masking elements in the interface enables you to hide the content from being recorded without loosing interaction data (e.g. clicks, hovers) on that element. ' + 'Click the element in the interface that you would like to mask. ' + 'The CSS selectors of the selected elements will appear in the list below. ' + '</p>' + '<p>' + 'Click "Hide to navigate" to mask more content or "Save and close" to apply changes. Check our <a href="https://help.mouseflow.com/en/articles/5973120-excluded-whitelisted-tracked-fields" target="_blank">Support Guide</a> for details and best practices.' + '</p>' + '<h3>Masked content</h3>' + '<div>' + '<output></output>' + '</div>' + '</div>' + '<div class="tool-whitelist' + (_1._28 === 'whitelist' ? ' active' : '') + '">' + '<h2>Whitelist input fields</h2>' + '<p>' + 'Mouseflow automatically masks all fields to protect personal data. However, you can whitelist specific input fields by clicking on them. ' + 'This allows Mouseflow to record input in those fields. ' + 'The CSS selectors of the selected elements will appear in the list below. ' + '</p>' + '<p>' + ' Click "Hide to navigate" to whitelist more input fields or "Save and close" to apply changes. Check our <a href="https://help.mouseflow.com/en/articles/5973120-excluded-whitelisted-tracked-fields" target="_blank">Support Guide</a> for details and best practices.' + '</p>' + '<h3>Whitelisted fields</h3>' + '<div>' + '<output></output>' + '</div>' + '</div>' + '<div class="tool-track' + (_1._28 === 'track' ? ' active' : '') + '">' + '<h2>Tracked elements</h2>' + '<p>' + 'When viewing a Heatmap, most links show interaction data (e.g. clicks and hovers).' + 'If you&quot;ve found an element that is not being tracked, you can select it here. ' + 'This will ensure the additional metrics are shown in your Heatmaps. ' + 'The CSS selectors of the selected elements will appear in the list below. ' + '</p>' + '<p>' + 'Click "Hide to navigate" or "Save and close" to finish. Check our <a href="https://help.mouseflow.com/en/articles/5973120-excluded-whitelisted-tracked-fields" target="_blank">Support Guide</a> for details and best practices.' + '</p>' + '<h3>Tracked elements</h3>' + '<div>' + '<output></output>' + '</div>' + '</div>' + '<div class="tool-status">' + '<div class="tool-status-text">' + _222(_1._39, _1._40, _1._56, _1._61) + '</div>' + '<div class="tool-status-buttons">' + '<button type="submit" class="btn-widget">Save and close</button>' + '<a href="#" class="green bold mf-tool-close">Close Privacy Tool</a>' + '</div>' + '</div>' + '<div class="tool-loading">' + '<h2 class="loading">Loading the Privacy Tool<i>.</i><i>.</i><i>.</i></h2>' + '</div>' + '<div class="tool-message">' + '<h3>Browser window is to small to load the Privacy Tool</h3>' + '<p>To use Mouseflow\'s Privacy Tool, you need to view the page in a larger browser window.</p>' + '</div>' + '</div>' + '</div>')
            }

            function _400(_19) {
                return _19.map(function(_2) {
                    return ('<div class="tm-tag" data-target="' + _6._80(_2) + '">' + _6._80(_2) + '<a href="#" class="btn-cross mf-remove-excluded"></a>' + '</div>')
                }).join('')
            }

            function _399(_19) {
                return _19.map(function(_2) {
                    return ('<div class="tm-tag" data-target="' + _6._80(_2) + '">' + _6._80(_2) + '<a href="#" class="btn-cross mf-remove-whitelisted"></a>' + '</div>')
                }).join('')
            }

            function _398(_19) {
                return _19.map(function(_2) {
                    return ('<div class="tm-tag" data-target="' + _6._80(_2) + '">' + _6._80(_2) + '<a href="#" class="btn-cross mf-remove-tracked"></a>' + '</div>')
                }).join('')
            }

            function _397(_19) {
                return _19.map(function(_2) {
                    return ('<div class="tm-tag" data-target="' + _6._80(_2) + '">' + _6._80(_2) + '<a href="#" class="btn-cross mf-remove-masked"></a>' + '</div>')
                }).join('')
            }

            function _222(_39, _40, _252, _250) {
                return '<p>You have:</p>' + '<p>' + '&nbsp;&bull; excluded <i class="emphasis"> ' + _39.length + '</i> ' + (_39.length === 1 ? 'element' : 'elements') + '<br>' + '&nbsp;&bull; masked <i class="emphasis"> ' + _250.length + '</i> ' + (_250.length === 1 ? 'element' : 'elements') + '<br>' + '&nbsp;&bull; whitelisted <i class="emphasis">' + _40.length + '</i> input ' + (_40.length === 1 ? 'field' : 'fields') + '<br>' + '&nbsp;&bull; tracked <i class="emphasis">' + _252.length + '</i> input ' + (_252.length === 1 ? 'element' : 'elements') + '</p>'
            }

            function _393() {
                var _263 = new CSSStyleSheet();
                _263.replace(_221());
                return _263
            }

            function _221() {
                return ('@font-face {' + 'font-family: "Open Sans";' + 'font-style: normal;' + 'font-weight: 400;' + 'src: url(https://cdn.mouseflow.com/fonts/opensans/opensans-regular.woff2) format("woff2");' + '}' + '@font-face {' + 'font-family: "Open Sans";' + 'font-style: normal;' + 'font-weight: 700;' + 'src: url(https://cdn.mouseflow.com/fonts/opensans/opensans-bold.woff2) format("woff2");' + '}' + ':root,' + ':host {' + '--deep-ocean: #08163c;' + '--dusty-cloud: #f7f9fc;' + '--dark-border: #bbc8e0;' + '--lighter-navy: #d4dbe3;' + '--dark-mode: #10172D;' + '--serious-business: #0b65e3;' + '--light-blue: #66A7FD;' + '--subtle-warmth: #7162e3;' + '--lighter-aqua: #ebf2fa;' + '--dusty-cloud-darker: #E4E9F2;' + '--deep-ocean-light: #A1B2D3;' + '--redwine-vibes: #cd575f;' + '}' + '.mf-highlight {' + 'cursor: pointer !important;' + '}' + '.mf-privacy-tool-opened iframe {' + 'pointer-events: none;' + '}' + '#mouseflow {' + 'font-weight: 400;' + 'font-family: \'Open Sans\', Arial, sans-serif;' + '}' + '#mouseflow .highlight-box {' + 'background-color: #add8e6;' + 'border: 2px dotted #808080;' + 'position: absolute;' + 'border-radius: 2px;' + 'z-index: 2147483646;' + 'cursor: pointer;' + 'pointer-events: none;' + 'opacity: 0.5;' + '-webkit-transition: opacity .075s linear;' + 'transition: opacity .075s linear;' + '}' + '#mouseflow .highlight-box.hidden,' + '#mouseflow .tool-closed .highlight-box {' + 'opacity: 0;' + '}' + '#mouseflow .highlight-box.highlight-excluded {' + 'background-color: #FFD2CF80;' + 'opacity: 1;' + 'pointer-events: initial;' + '}' + '#mouseflow .highlight-box.highlight-whitelisted {' + 'background-color: #70C59780;' + 'opacity: 1;' + 'pointer-events: initial;' + '}' + '#mouseflow .highlight-box.highlight-tracked {' + 'background-color: #92C6FB80;' + 'opacity: 1;' + 'pointer-events: initial;' + '}' + '#mouseflow .highlight-box.highlight-masked {' + 'background-color: #FFECBD80;' + 'opacity: 1;' + 'pointer-events: initial;' + '}' + '#mouseflow .tool-closed .highlight-box.highlight-excluded,' + '#mouseflow .tool-closed .highlight-box.highlight-whitelisted,' + '#mouseflow .tool-closed .highlight-box.highlight-masked,' + '#mouseflow .tool-closed .highlight-box.highlight-tracked {' + 'pointer-events: none;' + '}' + '#mouseflow .btn-widget {' + 'background: var(--serious-business);' + '}' + '#mouseflow .widget-header {' + 'background: var(--dusty-cloud);' + '}' + '#mouseflow .widget-text,' + '#mouseflow .btn-arrow,' + '#mouseflow .btn-cross {' + 'color: var(--deep-ocean);' + '}' + '#mouseflow .btn-widget {' + 'color: white;' + '}' + '#mouseflow .tm-tag {' + 'margin: 7px 7px 0 0;' + 'padding: 7px;' + 'display: inline-block;' + 'border-radius: 8px;' + 'border: 1px solid var(--dark-border);' + 'background-color: var(--dusty-cloud);' + 'color: var(--deep-ocean);' + 'font-size: 13px;' + '}' + '#mouseflow .step {' + 'visibility: hidden;' + 'opacity: 0;' + 'position: fixed;' + 'bottom: 30px;' + 'right: 30px;' + 'z-index: 2147483647;' + 'width: 300px;' + 'border-radius: 8px;' + 'border: 1px solid var(--deep-ocean);' + 'overflow: hidden;' + '}' + '#mouseflow a:hover {' + 'text-decoration: underline;' + '}' + '#mouseflow h2 {' + 'font-size: 21px;' + 'font-weight: 700;' + 'line-height: 1.4em;' + 'margin-bottom: 6px;' + '}' + '#mouseflow h3 {' + 'font-size: 16px;' + 'font-weight: 700;' + 'line-height: 1.4em;' + 'color: #08163C;' + '}' + '#mouseflow p {' + 'margin-bottom: 8px;' + 'line-height: 1.4em;' + '}' + '#mouseflow .green {' + 'color: var(--deep-ocean);' + '}' + '#mouseflow .red {' + 'color: var(--redwine-vibes);' + '}' + '#mouseflow .emphasis {' + 'color: var(--subtle-warmth);' + 'font-weight: 700;' + '}' + '#mouseflow .bold {' + 'font-weight: 700;' + '}' + '#mouseflow .tool-container {' + 'visibility: visible;' + 'opacity: 0;' + 'position: fixed;' + 'bottom: 0;' + 'left: 0;' + 'width: 100%;' + 'height: 350px;' + 'max-height: 40%;' + 'overflow: hidden;' + 'background-color: white;' + 'box-shadow: 0 0 6px var(--deep-ocean-light);' + 'z-index: 2147483647;' + '}' + '#mouseflow .tool-header {' + 'background-color: var(--dusty-cloud);' + 'height: 58px;' + 'border: 1px solid var(--dusty-cloud-darker);' + '}' + '#mouseflow .tool-title { ' + 'display: flex;' + 'vertical-align: middle;' + 'align-items: center;' + '}' + '#mouseflow .logo {' + 'display: inline;' + 'height: 30px;' + 'margin: 14px 10px;' + 'fill: black;' + '}' + '#mouseflow .tool-toggle,' + '#mouseflow .tool-close {' + 'margin-left: auto;' + 'padding: 18px 24px;' + '}' + '#mouseflow .is-loading .tool-close {' + 'display: block;' + '}' + '#mouseflow .is-loading .tool-toggle,' + '#mouseflow .tool-close {' + 'display: none;' + '}' + '#mouseflow .tool-toggle-text {' + 'display: inline-block;' + 'color: var(--deep-ocean);' + 'font-size: 16px;' + 'font-weight: 700;' + '}' + '#mouseflow .tool-toggle-icon {' + 'width: 23px;' + 'display: inline-block;' + 'position: relative;' + 'top: 0px;' + '}' + '#mouseflow .tool-close .tool-toggle-icon {' + 'top: 4px;' + '}' + '#mouseflow .tool-content {' + 'height: calc(100% - 58px);' + '}' + '#mouseflow .tool-menu {' + 'width: 15%;' + 'height: 100%;' + 'float: left;' + '}' + '#mouseflow .tool-menu-item {' + 'background-color: var(--dusty-cloud);' + 'color: var(--deep-ocean);' + 'cursor: pointer;' + 'height: 40px;' + 'padding: 12px;' + '}' + '#mouseflow .tool-menu-item.active {' + 'position: relative;' + 'background-color: var(--lighter-navy);' + 'color: var(--deep-ocean);' + 'cursor: default;' + '}' + '#mouseflow .tool-exclude,' + '#mouseflow .tool-whitelist,' + '#mouseflow .tool-track,' + '#mouseflow .tool-masked {' + 'display: none;' + 'width: 70%;' + 'height: 100%;' + 'float: left;' + 'color: var(--deep-ocean);' + 'overflow-y: auto;' + 'overflow-x: hidden;' + 'padding: 10px 20px;' + '}' + '#mouseflow .tool-exclude p, #mouseflow .tool-whitelist p, #mouseflow .tool-track p, #mouseflow .tool-masked p {' + 'color: black;' + '}' + '#mouseflow .tool-exclude.active,' + '#mouseflow .tool-whitelist.active,' + '#mouseflow .tool-masked.active,' + '#mouseflow .tool-track.active {' + 'display: block;' + '}' + '#mouseflow .tool-exclude::-webkit-scrollbar,' + '#mouseflow .tool-whitelist::-webkit-scrollbar,' + '#mouseflow .tool-masked::-webkit-scrollbar,' + '#mouseflow .tool-track::-webkit-scrollbar {' + 'width: 8px;' + '}' + '#mouseflow .tool-exclude::-webkit-scrollbar-track,' + '#mouseflow .tool-whitelist::-webkit-scrollbar-track,' + '#mouseflow .tool-masked::-webkit-scrollbar-track,' + '#mouseflow .tool-track::-webkit-scrollbar-track {' + 'border-radius: 10px;' + 'background-color: #F5F5F5;' + '-webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3);' + '}' + '#mouseflow .tool-exclude::-webkit-scrollbar-thumb,' + '#mouseflow .tool-whitelist::-webkit-scrollbar-thumb,' + '#mouseflow .tool-masked::-webkit-scrollbar-thumb,' + '#mouseflow .tool-track::-webkit-scrollbar-thumb {' + 'border-radius: 10px;' + 'background-color: #a7a7a7;' + '-webkit-box-shadow: inset 0 0 6px rgba(0,0,0,.3);' + '}' + '#mouseflow .tool-status {' + 'width: 15%;' + 'background-color: var(--dusty-cloud);' + 'color: var(--deep-ocean);' + 'height: 100%;' + 'float: left;' + 'position: relative;' + '}' + '#mouseflow .tool-status-text {' + 'font-size: 16px;' + 'font-weight: 300;' + 'text-align: left;' + 'padding: 0 15px;' + 'position: absolute;' + 'top: 40px;' + '}' + '#mouseflow .tool-status-buttons {' + 'width: 100%;' + 'text-align: center;' + 'position: absolute;' + 'padding: 0 30px;' + 'bottom: 40px;' + '}' + '#mouseflow .tool-loading {' + 'width: 100%;' + 'height: calc(100% - 58px);' + 'background-color: white;' + 'color: rgb(71, 64, 62);' + 'position: absolute;' + 'top: 58px;' + 'z-index: 2;' + 'visibility: hidden;' + 'opacity: 0;' + '-webkit-animation: fadeOut .3s linear;' + 'animation: fadeOut .3s linear;' + '}' + '#mouseflow .is-loading .tool-loading {' + 'visibility: visible;' + 'opacity: 1;' + '-webkit-animation: fadeIn .3s linear;' + 'animation: fadeIn .3s linear;' + '}' + '#mouseflow .tool-loading h2 {' + 'position: absolute;' + 'left: 50%;' + 'top: 50%;' + '-webkit-transform: translate(-50%, -50%);' + '-ms-transform: translate(-50%, -50%);' + 'transform: translate(-50%, -50%);' + '}' + '#mouseflow .widget-header {' + 'color: #fff;' + 'padding: 12px 15px;' + 'vertical-align: middle;' + 'overflow: hidden;' + 'position: relative;' + 'z-index: 1;' + '-webkit-transition: opacity .3s linear;' + 'transition: opacity .3s linear;' + '}' + '#mouseflow .widget-header:hover {' + 'background-color: var(--lighter-aqua);' + '}' + '#mouseflow .widget-text {' + 'font-size: 16px;' + 'line-height: 20px;' + 'width: 245px;' + 'display: inline-block;' + 'vertical-align: middle;' + '}' + '#mouseflow .widget-toggle {' + 'width: 20px;' + 'display: inline-block;' + 'vertical-align: middle;' + 'margin: 0;' + '}' + '#mouseflow .btn-arrow,' + '#mouseflow .btn-cross {' + 'float: right;' + 'z-index: 10;' + 'line-height: .5;' + '}' + '#mouseflow .tool-toggle-icon .btn-arrow,' + '#mouseflow .tool-toggle-icon .btn-cross {' + 'font-size: 23px;' + '}' + '#mouseflow .widget-toggle .btn-arrow {' + 'font-size: 23px;' + '}' + '#mouseflow .tm-tag .btn-cross {' + 'margin: 3px 0 0 7px;' + 'font-weight: 700;' + 'font-size: 16px;' + '}' + '#mouseflow .btn-arrow--up {' + '-webkit-transform: rotate(-90deg) scale(1.5, 1.5);' + '-ms-transform: rotate(-90deg) scale(1.5, 1.5);' + 'transform: rotate(-90deg) scale(1.5, 1.5);' + '}' + '#mouseflow .btn-arrow--down {' + '-webkit-transform: rotate(+90deg) scale(1.5, 1.5);' + '-ms-transform: rotate(+90deg) scale(1.5, 1.5);' + 'transform: rotate(+90deg) scale(1.5, 1.5);' + '}' + '#mouseflow .widget-toggle .btn-arrow:before {' + 'content: "";' + 'display: inline;' + 'position: absolute;' + 'top: -185px;' + 'left: -15px;' + 'right: -15px;' + 'bottom: -15px;' + 'display: block;' + '}' + '#mouseflow .tool-toggle-icon .btn-arrow:before {' + 'content: "";' + 'display: inline;' + 'position: absolute;' + 'top: -10px;' + 'left: -15px;' + 'right: -15px;' + 'bottom: -100px;' + 'display: block;' + '}' + '#mouseflow .tool-toggle-icon .btn-cross:before {' + 'content: "";' + 'display: inline;' + 'position: absolute;' + 'top: -25px;' + 'left: -150px;' + 'right: -20px;' + 'bottom: -20px;' + 'display: block;' + '}' + '#mouseflow .btn-arrow:after {' + 'content: "\\203a";' + 'display: inline;' + '}' + '#mouseflow .btn-cross:after {' + 'content: "\\00d7";' + 'display: inline;' + 'top: -4px;' + 'position: relative;' + '}' + '#mouseflow .tm-tag .btn-cross:after {' + 'top: 0px;' + '}' + '#mouseflow .btn-arrow:hover,' + '#mouseflow .btn-cross:hover {' + 'text-decoration: none;' + '}' + '#mouseflow .btn-widget {' + 'width: 100%;' + 'height: 38px;' + 'border: none;' + 'border-radius: 8px;' + 'overflow: hidden;' + 'position: relative;' + 'z-index: 1;' + 'cursor: pointer;' + 'display: block;' + 'padding: 10px;' + 'font-size: 16px;' + 'font-family: inherit;' + 'font-weight: bold;' + 'text-align: center;' + 'outline: none;' + 'color: var(--dusty-cloud);' + 'margin-bottom: 10px;' + '-webkit-transition: background-color .3s linear;' + 'transition: background-color .3s linear;' + '}' + '#mouseflow .btn-widget:hover {' + 'text-decoration: none;' + 'background-color: var(--light-blue);' + '}' + '#mouseflow .privacy-tool {' + 'height: 350px;' + 'max-height: 40%;' + '-webkit-transition: height .5s ease-out;' + 'transition: height .5s ease-out;' + '}' + '#mouseflow .privacy-tool.tool-closed {' + 'height: 0;' + '}' + '#mouseflow .tool-closed .step {' + 'visibility: visible;' + '}' + '#mouseflow .tool-closed .tool-container {' + 'visibility: hidden;' + '}' + '#mouseflow .step.fade-in,' + '#mouseflow .tool-container.fade-in {' + '-webkit-animation: fadeUpIn .8s cubic-bezier(0, 0, 0, 1) both;' + 'animation: fadeUpIn .8s cubic-bezier(0, 0, 0, 1) both;' + '}' + '#mouseflow .step.fade-out,' + '#mouseflow .tool-container.fade-out {' + '-webkit-animation: fadeDownOut .8s cubic-bezier(0, 0, 0, 1);' + 'animation: fadeDownOut .8s cubic-bezier(0, 0, 0, 1);' + '}' + '#mouseflow .btn-widget.loading {' + 'cursor: default;' + '}' + '#mouseflow .btn-widget.loading:before {' + 'display: none;' + '}' + '#mouseflow .loading i {' + 'animation-name: blink;' + 'animation-duration: 1.4s;' + 'animation-iteration-count: infinite;' + 'animation-fill-mode: both;' + '}' + '#mouseflow .loading i:nth-child(2) {' + 'animation-delay: .2s;' + '}' + '#mouseflow .loading i:nth-child(3) {' + 'animation-delay: .4s;' + '}' + '#mouseflow .loading i:nth-child(4) {' + 'animation-delay: .6s;' + '}' + '#mouseflow .tool-message {' + 'width: 100%;' + 'height: calc(100% - 58px);' + 'background-color: white;' + 'color: rgb(71, 64, 62);' + 'position: absolute;' + 'top: 58px;' + 'z-index: 3;' + 'padding: 20px;' + 'overflow-y: auto;' + 'overflow-x: hidden;' + 'visibility: hidden;' + 'opacity: 0;' + '-webkit-animation: fadeOut .3s linear;' + 'animation: fadeOut .3s linear;' + '}' + '#mouseflow .tool-message h3 {' + 'margin-bottom: 20px;' + '}' + '@media (max-width: 1300px) {' + '#mouseflow .tool-exclude,' + '#mouseflow .tool-whitelist,' + '#mouseflow .tool-masked,' + '#mouseflow .tool-track {' + 'width: 60%;' + '}' + '#mouseflow .tool-status {' + 'width: 25%;' + '}' + '#mouseflow .tool-status-buttons {' + 'bottom: 10px;' + '}' + '}' + '@media (max-width: 850px) {' + '#mouseflow .tool-menu-item {' + 'height: 56px;' + '}' + '#mouseflow .tool-status-text {' + 'font-size: 14px;' + '}' + '#mouseflow .btn-widget {' + 'font-size: 12px;' + '}' + '#mouseflow a.mf-tool-close {' + 'font-size: 12px;' + '}' + '}' + '@media (max-height: 800px) {' + '#mouseflow .tool-status-text {' + 'top: 20px;' + '}' + '#mouseflow .tool-status-buttons {' + 'bottom: 20px;' + '}' + '}' + '@media (max-height: 650px) {' + '#mouseflow .tool-status-text {' + 'font-size: 14px;' + '}' + '}' + '@media (max-width: 650px), (max-height: 600px) {' + '#mouseflow .tool-message {' + 'visibility: visible;' + 'opacity: 1;' + '-webkit-animation: fadeIn .3s linear;' + 'animation: fadeIn .3s linear;' + '}' + '}' + '@-webkit-keyframes fadeUpIn {' + '0% {' + '-webkit-transform: translateY(50px);' + '-ms-transform: translateY(50px);' + 'transform: translateY(50px);' + 'opacity: 0;' + '}' + '100% {' + '-webkit-transform: translateY(0);' + '-ms-transform: translateY(0);' + 'transform: translateY(0);' + 'opacity: 1;' + '}' + '}' + '@keyframes fadeUpIn {' + '0% {' + '-webkit-transform: translateY(50px);' + '-ms-transform: translateY(50px);' + 'transform: translateY(50px);' + 'opacity: 0;' + '}' + '100% {' + '-webkit-transform: translateY(0);' + '-ms-transform: translateY(0);' + 'transform: translateY(0);' + 'opacity: 1;' + '}' + '}' + '@-webkit-keyframes fadeDownOut {' + '0% {' + 'visibility: visible;' + '-webkit-transform: translateY(0);' + '-ms-transform: translateY(0);' + 'transform: translateY(0);' + 'opacity: 1;' + '}' + '100% {' + 'visibility: hidden;' + '-webkit-transform: translateY(50px);' + '-ms-transform: translateY(50px);' + 'transform: translateY(50px);' + 'opacity: 0;' + '}' + '}' + '@keyframes fadeDownOut {' + '0% {' + 'visibility: visible;' + '-webkit-transform: translateY(0);' + '-ms-transform: translateY(0);' + 'transform: translateY(0);' + 'opacity: 1;' + '}' + '100% {' + 'visibility: hidden;' + '-webkit-transform: translateY(50px);' + '-ms-transform: translateY(50px);' + 'transform: translateY(50px);' + 'opacity: 0;' + '}' + '}' + '@-webkit-keyframes fadeIn {' + '0% {' + 'visibility: visible;' + 'opacity: 0;' + '}' + '100% {' + 'visibility: visible;' + 'opacity: 1;' + '}' + '}' + '@keyframes fadeIn {' + '0% {' + 'visibility: visible;' + 'opacity: 0;' + '}' + '100% {' + 'visibility: visible;' + 'opacity: 1;' + '}' + '}' + '@-webkit-keyframes fadeOut {' + '0% {' + 'visibility: visible;' + 'opacity: 1;' + '}' + '100% {' + 'visibility: hidden;' + 'opacity: 0;' + '}' + '}' + '@keyframes fadeOut {' + '0% {' + 'visibility: visible;' + 'opacity: 1;' + '}' + '100% {' + 'visibility: hidden;' + 'opacity: 0;' + '}' + '}' + '@keyframes blink {' + '0% {' + 'opacity: .2;' + '}' + '20% {' + 'opacity: 1;' + '}' + '100% {' + 'opacity: .2;' + '}' + '}')
            }
            this._37 = _37;
            this._64 = _64
        }

        function _368(_0, _59, _44, _6, _13, _5, _69) {
            var _7, _32, _73, _18, _261, _226;

            function _37(_100, _152, _406, _78) {
                _18 = _152;
                _7 = _100;
                _226 = _78;
                _261 = !!_406;
                _7('Tagger tool starting');
                _32 = _59._116();
                if (!_32) {
                    _7('Tagger tool not initiated - could not create root HTML element');
                    return
                }
                if (!_0.opener) {
                    _7('Tagger tool not initiated - window.opener is missing');
                    return
                }
                _103()
            }

            function _103() {
                _13._17(_0, 'message', function(_27) {
                    if (_27.origin !== _18) return;
                    _150(_27.data);
                    switch (_27.data.message) {
                        case 'MouseflowTaggerTool_Init_Received':
                            _0.clearInterval(_73);
                            break;
                        case 'MouseflowTaggerTool_Init_Success':
                            _135(_27.data.scripts, function() {
                                taggerToolWidget.start(_69._131());
                                if (typeof _226 === 'function') _226();
                                _7('Tagger tool scripts loaded')
                            });
                            break
                    }
                });
                _73 = _0.setInterval(_264, 500);
                _0.setTimeout(function() {
                    _0.clearInterval(_73)
                }, 10000);
                _264()
            }

            function _264() {
                _98({
                    message: 'MouseflowTaggerTool_Init',
                    startWithHeatMap: _261
                })
            }

            function _135(_84, _78) {
                if (!_84) return;
                var _101 = 0;

                function _157() {
                    if (_101 >= _84.length) {
                        _78();
                        return
                    }
                    var _33 = _84[_101];
                    _213(_33);
                    _101++;
                    var _88 = document.createElement('script');
                    if (_33.startsWith('/')) _88.src = _18 + _33;
                    else _88.src = _18 + '/' + _33;
                    _88.onload = _157;
                    _32.appendChild(_88)
                }
                _157()
            }

            function _213(_33) {
                _7('Tagger tool loading script: ' + _33)
            }

            function _150(_15) {
                if (_15.message && _15.message.indexOf('MouseflowTaggerTool_') === 0) _7('Received ' + _15.message + (_15.requestUrl ? ', request URL: ' + _15.requestUrl : ''))
            }

            function _98(_15) {
                _0.opener.postMessage(_15, _18);
                _7('Sent ' + _15.message + (_15.requestUrl ? ', request URL: ' + _15.requestUrl : ''))
            }
            this._37 = _37
        }

        function _340(_5, _227, _230) {
            function _131() {
                if (_5.forcePath && _5.path) return _5.path.toLowerCase();
                var _43 = (_5.crossDomainSupport ? _5.location.hostname : '') + (_5.path || (_5.decodePathName ? decodeURIComponent(_5.location.pathname) : _5.location.pathname)).toLowerCase();
                var _249 = (_5.includeHashInPath ? _5.location.hash : '').toLowerCase();
                var _75 = _5.location.search.toLowerCase();
                if (_43 !== '/' && _43.slice(-1) === '/' && (!_5.includeQueryStringInPath && !_5.includeHashInPath)) _43 = _43.slice(0, -1);
                return _417(_43 + (_5.includeQueryStringInPath ? _75 : '') + _249) || _43 + _416(_75) + _249
            }

            function _417(_43) {
                return _227.filter(function(_35) {
                    return _414(_43, _35)
                }).map(function(_35) {
                    return _411(_35)
                })[0]
            }

            function _416(_75) {
                if (_75[0] === '?') _75 = _75.slice(1);
                var _55;
                var _210 = [];
                var _415 = /([^&=]+)=?([^&]*)/g;
                while ((_55 = _415.exec(_75)) !== null) {
                    var _36 = _230.indexOf(_55[1]);
                    if (_55[2] && _36 > -1) _210[_36] = _55[0]
                }
                return _210.length ? '?' + _210.filter(hasValue).join('&') : (_5.includeQueryStringInPath && _75 ? '?' + _75 : '')
            }

            function _414(_43, _35) {
                var _247 = _43.indexOf('?');
                if (!_5.includeQueryStringInPath && _247 > -1) _43 = _43.slice(0, _247);
                switch (_35._123) {
                    case 'equals':
                        return _43 === _35._8.toLowerCase();
                    case 'startsWith':
                        return _43.substr(0, _35._8.length) === _35._8;
                    case 'endsWith':
                        return _43.substr(-_35._8.length) === _35._8;
                    case 'contains':
                        return _43.includes(_35._8.toLowerCase());
                    case 'regex':
                        return new RegExp(_35._8).test(_43);
                    default:
                        return false
                }
            }

            function _411(_35) {
                if (_35._410) return _35._410;
                switch (_35._123) {
                    case 'startsWith':
                        return _35._8 + '*';
                    case 'endsWith':
                        return '*' + _35._8;
                    default:
                        return _35._8
                }
            }

            function hasValue(value) {
                return value
            }
            this._131 = _131
        }

        function _294(_123, _0, _6, _7) {
            var _122 = _413(_123);
            this._124 = function(_11) {
                try {
                    return _122.getItem(_11) || null
                } catch (e) {
                    _7(e);
                    return null
                }
            };
            this._212 = function(_11) {
                try {
                    return _6._186(this._124(_11)) || null
                } catch (e) {
                    _7(e);
                    return null
                }
            };
            this._178 = function(_11, _8) {
                try {
                    _122.setItem(_11, _8);
                    return true
                } catch (e) {
                    _7(e);
                    return false
                }
            };
            this._216 = function(_11, _8) {
                try {
                    return this._178(_11, _6._156(_8))
                } catch (e) {
                    _7(e);
                    return false
                }
            };
            this._218 = function(_11) {
                try {
                    _122.removeItem(_11)
                } catch (e) {
                    _7(e)
                }
            };
            this._373 = function() {
                try {
                    var _11 = 'mf_supportsSessionStorage';
                    var _8 = '1';
                    _122.setItem(_11, _8);
                    var _412 = _122.getItem(_11) === _8;
                    _122.removeItem(_11);
                    return _412
                } catch (e) {
                    _7(e);
                    return false
                }
            };

            function _413(_123) {
                switch (_123) {
                    case 'local':
                        return _0.localStorage;
                    case 'session':
                        return _0.sessionStorage;
                    default:
                        throw Error('Unknown storage type: ' + (_123 || 'null'))
                }
            }
        }

        function _418(_0, _6, _5, _7) {
            var _12 = _0.document;
            var _60 = _0.location;
            var _421 = 7776000000;
            this._420 = function(_66) {
                var _326 = _66 + '=';
                var _327 = _12.cookie.split(';');
                for (var i = 0; i < _327.length; i++) {
                    var c = _327[i];
                    while (c.charAt(0) === ' ') {
                        c = c.substring(1)
                    }
                    if (c.indexOf(_326) === 0) {
                        return c.substring(_326.length, c.length)
                    }
                }
                return ''
            };
            this._124 = function(_11) {
                try {
                    return this._420(_11)
                } catch (e) {
                    _7(e);
                    return null
                }
            };
            this._212 = function(_11) {
                try {
                    return _6._186(this._124(_11)) || null
                } catch (e) {
                    _7(e);
                    return null
                }
            };
            this._409 = function(_66, _8, _159, _62) {
                var _316 = '';
                if (_159 == 1) {
                    var _114 = new Date();
                    _114.setTime(_114.getTime() + _421);
                    _316 = '; expires=' + _114.toGMTString()
                }
                var _424 = _5.secureCookie ? 'secure;' : '';
                _12.cookie = _66 + '=' + _8 + _316 + '; path=/; domain=' + _62 + ';' + _424 + 'SameSite=Strict;'
            };
            this._178 = function(_11, _8, _159, _62) {
                try {
                    this._409(_11, _8, _159, _62);
                    return true
                } catch (e) {
                    _7(e);
                    return false
                }
            };
            this._216 = function(_11, _8, _159, _62) {
                try {
                    return this._178(_11, _6._156(_8), _159, _62)
                } catch (e) {
                    _7(e);
                    return false
                }
            };
            this._218 = function(_11) {
                try {
                    _12.cookie = _11 + '=; expires=Thu, 01-Jan-70 00:00:01 GMT; path=/; domain=' + _6._199(_60, _5) + ';'
                } catch (e) {
                    _7(e)
                }
            }
        }

        function _333(_0, _6, _5, _7) {
            this._408 = function() {
                _0._mfq = []
            };
            this._129 = function() {
                if (!_0._mfq) this._408();
                for (var _36 = 0; _36 < _0._mfq.length; _36++) {
                    var _53 = _0._mfq[_36];
                    if (_53 && _53.length) {
                        var _298 = true;
                        if (_53[0] === 'config') _5._174.apply(_5, _53.slice(1));
                        else if (_53[0] === 'newPageView') _5._248.apply(_5, _53.slice(1));
                        else _298 = false;
                        if (_298) delete _0._mfq[_36]
                    }
                }
            };
            this._37 = function() {
                _0._mfq = new _128(_0._mfq)
            };
            this._474 = function() {
                _0._mfq.push.apply(_0._mfq, arguments)
            };
            this._475 = function() {
                return _0._mfq
            };

            function _128(_175) {
                if (!_175) _175 = [];
                var _392 = this;
                _0.setTimeout(function() {
                    for (var _36 = 0; _36 < _175.length; _36++) _392.push(_175[_36])
                }, 1)
            }
            _128.prototype.push = function(_53) {
                if (!_53) return;
                try {
                    if (typeof _53 === 'object' && _53.length) {
                        _0.mouseflow[_53.slice(0, 1)].apply(_0.mouseflow, _53.slice(1))
                    } else if (typeof _53 === 'function') {
                        _53(_0.mouseflow)
                    }
                } catch (error) {
                    var _108 = 'Failed to execute item on action queue';
                    var _295 = _6._156(_53);
                    if (_295) _108 += '\n' + _295;
                    _108 += '\n' + error;
                    _7(_108)
                }
            }
        }

        function _395(_41, _6) {
            var _194 = [];
            var _455 = ['target', 'button', 'pageX', 'pageY', 'which', 'data', 'origin', 'source', 'touches', 'key', 'clientX', 'clientY'];

            function _444(_63, _125, _51, _201, _46) {
                var _52 = !!_46._52;
                var _312 = function(_9) {
                    var _151 = [];
                    if (_9.composedPath && ((_9.target && _9.target.shadowRoot) || _51)) _151 = _9.composedPath();
                    var _313 = _9;
                    _9 = _451(_9);
                    _9.preventDefault = function() {
                        _313.preventDefault()
                    };
                    _9.stopPropagation = function() {
                        _313.stopPropagation()
                    };
                    if (_9.target && _9.target.shadowRoot && _151.length) _9.target = _151[0];
                    if (_51) {
                        _9.delegatedTarget = _303(function(_90, _4) {
                            return _151.length ? _151[_4] : (_90 ? _41._266(_90) : _9.target)
                        }, _51);
                        if (!_9.delegatedTarget && !_46._477) return;
                        if (_46._225 && _9.target !== _9.delegatedTarget) return
                    } else if (_46._225 && _9.target !== _63) {
                        return
                    }
                    if (_46._47) _9.preventDefault();
                    if (_46._479) _9.stopPropagation();
                    _201.apply(this, arguments)
                };
                _63.addEventListener(_125, _312, {
                    capture: _52
                });
                _194.push({
                    _63: _63,
                    _125: _125,
                    _201: _312,
                    _52: _52
                })
            }

            function _451(_9) {
                var _305 = {};
                _455.forEach(function(_11) {
                    if (_9[_11] != undefined) _305[_11] = _9[_11]
                });
                return _305
            }

            function _438() {
                _194.forEach(function(_13) {
                    _13._63.removeEventListener(_13._125, _13._201, {
                        capture: _13._52
                    })
                });
                _194 = []
            }

            function _303(_302, _51, _63, _36) {
                if (!_36) _36 = 0;
                _63 = _302(_63, _36);
                if (!_63 || !_51) return null;
                if (_6._42(_63, _51)) return _63;
                return _303(_302, _51, _63, ++_36)
            }
            this._17 = function(_63, _125, _51, _78, _46) {
                if (typeof _51 === 'function') {
                    _46 = _78;
                    _78 = _51;
                    _51 = null
                }
                _444(_63, _125, _51, _78, _46 || {})
            };
            this._443 = _438
        }

        function _442(_0, _34, _143, _228, _202, _206) {
            const _60 = _0.location;
            const _12 = _0.document;
            const _390 = URL.parse ? ? _198;

            function _198(_31) {
                var _42 = (_31 || '').match(/^(([^:]+:)?\/?\/?(([^:/?#]+)?:?(\d+)?))(\/.*?)?(\?.*?)?(#.*)?$/);
                return {
                    href: _42[0] || '',
                    origin: _42[1] || '',
                    protocol: _42[2] || '',
                    host: _42[3] || '',
                    hostname: _42[4] || '',
                    port: _42[5] || '',
                    pathname: _42[6] || '',
                    search: _42[7] || '',
                    hash: _42[8] || ''
                }
            }

            function _322(_405) {
                if (_206) return '';
                const _31 = _390(_405);
                return _31 ? .protocol && _31 ? .origin ? _31.origin : ''
            }
            this.debug = _0.mouseflowDebug || _60.search.indexOf('mf_debug=1') !== -1;
            this.includeDebugTime = false;
            this.forceStart = _60.search.indexOf('mf_force=1') !== -1;
            this.autoStart = _0.mouseflowAutoStart !== false && _60.search.indexOf('mf_autostart=0') === -1;
            this.enableBots = false;
            this.touchEvents = !_0.mouseflowDisableTouch;
            this.htmlDelay = _0.mouseflowHtmlDelay || 1000;
            this.newPageViewHtmlDelay = _0.mouseflowNewPageViewHtmlDelay || 500;
            this.compress = _0.mouseflowCompress !== false && _60.search.indexOf('mf_compress=0') === -1;
            this.compressFunction = null;
            this.autoTagging = _0.mouseflowAutoTagging !== false;
            this.path = _0.mouseflowPath;
            this.forcePath = false;
            this.crossDomainSupport = !!_0.mouseflowCrossDomainSupport;
            this.location = _198(_0.mouseflowHref || _60.href);
            this.hasCustomHref = !!_0.mouseflowHref;
            this.referrer = _322(_0.mouseflowReferrer !== undefined ? _0.mouseflowReferrer : _12.referrer);
            this.htmlFetchMode = _0.mouseflowHtmlFetchMode || 'post';
            this.sessionId = _0.mouseflowSessionId;
            this.honorDoNotTrack = _0.mouseflowHonorDoNotTrack || _202;
            this.gdprEnabled = _0.mouseflowForceGdpr || _228;
            this.keyLogging = !_0.mouseflowDisableKeyLogging && !this.gdprEnabled;
            this.domReuse = !_0.mouseflowDisableDomReuse;
            this.domDeduplicator = !_0.mouseflowDisableDomDeduplicator;
            this.includeSubDomains = !_0.mouseflowExcludeSubDomains;
            this.registerSubmitTimeout = _0.mouseflowRegisterSubmitTimeout || 2000;
            this.useUnload = !!_0.mouseflowUseUnload;
            this.replaceLastFormValues = _0.mouseflowReplaceLastFormValues || !this.keyLogging || this.gdprEnabled;
            this.useAllHoverSelectors = !!_0.mouseflowUseAllHoverSelectors;
            this.enableCssRecording = !!_0.mouseflowEnableCssRecording;
            this.secureCookie = !!_0.mouseflowSecureCookie;
            this.enableSpa = true;
            this.includeHashInPath = false;
            this.includeQueryStringInPath = false;
            this.autoTagPayments = true;
            this.preferStorageApi = !!_0.mouseflowPreferStorageApi;
            this.domMutationDetectorEnable = _0.domMutationDetectorEnable !== undefined ? _0.domMutationDetectorEnable : false;
            this.domMutationUseParentNode = _0.domMutationUseParentNode !== undefined ? _0.domMutationUseParentNode : true;
            this.domMutationUsePreviousSibling = _0.domMutationUsePreviousSibling !== undefined ? _0.domMutationUsePreviousSibling : false;
            this.domMutationCountThreshold = _0.domMutationCountThreshold !== undefined ? _0.domMutationCountThreshold : 20;
            this.domMutationTimeThresholdInSeconds = _0.domMutationTimeThresholdInSeconds !== undefined ? _0.domMutationTimeThresholdInSeconds : 10;
            this.liveHeatmapsEnabled = false;
            this.privacyToolEnabled = false;
            this.taggerToolEnabled = false;
            this.useIdSelectors = _0.mouseflowUseIdSelectors !== undefined ? _0.mouseflowUseIdSelectors : true;
            this.proxyAttachShadow = true;
            this.scrollSelector = _0.mouseflowScrollSelector;
            this.autoScrollSelector = _0.mouseflowAutoScrollSelector || false;
            this.freezeElementIds = [];
            this.proxyValueSetter = false;
            this.decodePathName = false;
            this.forms = _0.mouseflowFormsConfiguration || null;
            this.notFoundIdentifiers = _0.mouseflowNotFoundIdentifiers || ["Not Found", "404"];
            this.debugDeadClick = _60.search.indexOf('mf_debugDeadClick=1') !== -1;
            this.enableDeadClick = true;
            this.enableDataLayerCapture = !!_0.mouseflowEnableDataLayerCapture;
            this._129 = function() {
                const _119 = typeof _0.name === 'string' && _0.name.startsWith('mf_') ? _0.name.slice(3).split('_') : [];
                if (`${_119[0]}_${_119[3]}` === 'liveHeatmaps_v3') {
                    this.liveHeatmapsV3Enabled = true;
                    _143._178('mf_liveHeatmaps_version', 'v3')
                } else if (_143._124('mf_liveHeatmaps_version') === 'v3') {
                    this.liveHeatmapsV3Enabled = true
                }
                if (!!_0.opener && _60.search.indexOf('mf_liveHeatmaps') !== -1) {
                    this.liveHeatmapsEnabled = true;
                    this.taggerToolEnabled = true;
                    return
                }
                if (_60.search.indexOf('mf_inspect') !== -1) {
                    this.privacyToolEnabled = true;
                    return
                }
                if (!!_0.opener && _119[0] === 'liveHeatmaps') {
                    this.liveHeatmapsEnabled = true;
                    this.taggerToolEnabled = true;
                    return
                }
                if (_119[0] === 'privacyTool') {
                    this.privacyToolEnabled = true;
                    return
                }
                if (`${_119[0]}_${_119[1]}` === 'tagger_tool') {
                    this.taggerToolEnabled = true;
                    return
                }
                if (!_34._373()) return;
                if (_0.opener) {
                    if (_34._124('mf_privacyTool')) this.privacyToolEnabled = true;
                    else if (_34._124('mf_liveHeatmaps')) {
                        this.liveHeatmapsEnabled = true;
                        this.taggerToolEnabled = true
                    }
                }
            };
            this._248 = function(_191, _60) {
                this._174('href', _0.location.href);
                this.path = undefined;
                if (_191) this.path = _191.toString();
                if (_60) {
                    this.location = _60;
                    this.hasCustomHref = true
                }
            };
            this._174 = function(_11, _8) {
                if (_11[0] === '_') return;
                switch (_11) {
                    case 'href':
                        this.location = _198(_8);
                        this.hasCustomHref = _8 !== _0.location.href;
                        break;
                    case 'keyLogging':
                        this.keyLogging = this.keyLogging && _8;
                        break;
                    case 'gdprEnabled':
                        this.gdprEnabled = this.gdprEnabled || _8;
                        break;
                    case 'freezeElementIds':
                        this.freezeElementIds = Array.isArray(_8) ? _8 : ['' + _8];
                        break;
                    case 'referrer':
                        this.referrer = _322(_8);
                        break;
                    case 'hasCustomHref':
                        break;
                    default:
                        this[_11] = _8;
                        break
                }
            }
        }

        function _338(_0, _41) {
            const _172 = 'mf-root';
            let _323, _112;
            _117(_0);

            function _117(_118) {
                _323 = _118;
                _112 = _118.document;
                _41._117(_118)
            }

            function _241() {
                if (!_112.body) return null;
                const _45 = _339();
                if (!_331()) _223();
                return _45
            }

            function _116() {
                const _32 = _241();
                const _45 = _32 ? .shadowRoot.getElementById('mouseflow');
                return _45
            }

            function _242() {
                const _45 = _314();
                if (!_45) return;
                const _325 = _323.getComputedStyle(_112.body);
                const _209 = parseInt(_325.marginTop) + parseInt(_325.paddingTop);
                if (_209) {
                    _45.style.top = `${_209 * -1}px`;
                    _45.style.height = `calc(100% + ${_209}px)`;
                    _45.style.left = '0px';
                    _45.style.width = '100%'
                }
            }

            function _314() {
                return _112.getElementsByTagName(_172)[0]
            }

            function _339() {
                const _45 = _314() ? ? _112.createElement(_172);
                if (!_45.id) _45.id = 'mouseflow';
                if (_45.innerHTML ? .trim() === '') _45.innerHTML = _334();
                if (!_112.contains(_45)) _112.body.appendChild(_45);
                _242();
                return _45
            }

            function _331() {
                return !!_41._402(_172)
            }

            function _223() {
                _41._223(_172, class extends _41._215('HTMLElement') {
                    connectedCallback() {
                        const _76 = this.shadowRoot ? ? this.attachShadow({
                            mode: 'open'
                        });
                        if (_76.getElementById('mouseflow')) return;
                        _76.innerHTML = ('<div id="mouseflow">' + '<style type="text/css">' + '@font-face {' + 'font-family: "Open Sans";' + 'font-style: normal;' + 'font-weight: 400;' + 'src: url(https://cdn.mouseflow.com/fonts/opensans/opensans-regular.woff2) format("woff2");' + '}' + '@font-face {' + 'font-family: "Open Sans";' + 'font-style: normal;' + 'font-weight: 700;' + 'src: url(https://cdn.mouseflow.com/fonts/opensans/opensans-bold.woff2) format("woff2");' + '}' + ':host {' + 'all: initial;' + 'font: 400 14px/1.4 "Open Sans", Arial, sans-serif;' + 'color: #666;' + '}' + '.load-font {' + 'position: absolute;' + 'visibility: hidden;' + 'width: 0px;' + 'height: 0px;' + 'overflow: hidden;' + '}' + '* {' + 'background: transparent;' + 'border: 0;' + 'border-image-outset: 0s;' + 'border-image-repeat: stretch;' + 'border-image-slice: 100%;' + 'border-image-source: none;' + 'border-image-width: 1;' + 'border-color: #000;' + 'border-radius: 0;' + 'border-width: 0;' + 'border-style: none;' + 'box-sizing: border-box;' + 'clip: auto;' + 'float: none;' + 'color: inherit;' + 'font-family: inherit;' + 'font-size: inherit;' + 'font-style: inherit;' + 'font-weight: inherit;' + 'width: auto;' + 'height: auto;' + 'min-width: auto;' + 'min-height: auto;' + 'max-width: auto;' + 'max-height: auto;' + 'letter-spacing: normal;' + 'line-height: normal;' + 'margin: 0;' + 'padding: 0;' + 'text-decoration: none;' + 'text-indent: 0;' + 'text-transform: none;' + 'vertical-align: baseline;' + 'text-align: left;' + 'overflow: visible;' + 'top: auto;' + 'right: auto;' + 'bottom: auto;' + 'left: auto;' + '-webkit-transition: none;' + 'transition: none;' + '}' + '.mf-is-hidden {' + 'display: none;' + '}' + '</style>' + '<div class="load-font">load font</div>' + '<slot />' + '</div>')
                    }
                })
            }

            function _334() {
                return ('<style type="text/css">' + '@font-face {' + 'font-family: "Mouseflow Open Sans";' + 'font-style: normal;' + 'font-weight: 400;' + 'src: url(https://cdn.mouseflow.com/fonts/opensans/opensans-regular.woff2) format("woff2");' + '}' + '@font-face {' + 'font-family: "Mouseflow Open Sans";' + 'font-style: normal;' + 'font-weight: 700;' + 'src: url(https://cdn.mouseflow.com/fonts/opensans/opensans-bold.woff2) format("woff2");' + '}' + '#mouseflow,' + 'mf-root {' + 'all: initial;' + 'font: 400 14px/1.4 "Mouseflow Open Sans", Arial, sans-serif;' + 'color: #666;' + '}' + '#mouseflow *,' + 'mf-root * {' + 'background: transparent;' + 'border: 0;' + 'border-image-outset: 0s;' + 'border-image-repeat: stretch;' + 'border-image-slice: 100%;' + 'border-image-source: none;' + 'border-image-width: 1;' + 'border-color: #000;' + 'border-radius: 0;' + 'border-width: 0;' + 'border-style: none;' + 'box-sizing: border-box;' + 'clip: auto;' + 'float: none;' + 'color: inherit;' + 'font-family: inherit;' + 'font-size: inherit;' + 'font-style: inherit;' + 'font-weight: inherit;' + 'width: auto;' + 'height: auto;' + 'min-width: auto;' + 'min-height: auto;' + 'max-width: auto;' + 'max-height: auto;' + 'letter-spacing: normal;' + 'line-height: normal;' + 'margin: 0;' + 'padding: 0;' + 'text-decoration: none;' + 'text-indent: 0;' + 'text-transform: none;' + 'vertical-align: baseline;' + 'text-align: left;' + 'overflow: visible;' + 'top: auto;' + 'right: auto;' + 'bottom: auto;' + 'left: auto;' + '-webkit-transition: none;' + 'transition: none;' + '}' + '#mouseflow .mf-is-hidden,' + 'mf-root .mf-is-hidden {' + 'display: none;' + '}' + '</style>')
            }
            this._117 = _117;
            this._241 = _241;
            this._116 = _116;
            this._242 = _242
        }

        function _330(_0) {
            this._97 = function() {
                return _160('setTimeout').apply(_0, arguments)
            };
            this._496 = function() {
                return _160('setInterval').apply(_0, arguments)
            };
            this._239 = function() {
                _160('clearTimeout').apply(_0, arguments)
            };
            this._497 = function() {
                _160('clearInterval').apply(_0, arguments)
            };

            function _160(_66) {
                var _309;
                if (_0.Zone && _0.Zone.__symbol__) _309 = _0[_0.Zone.__symbol__(_66)];
                return _309 || _0[_66]
            }
        }

        function _350(_0, _170, _244, _41) {
            var _12 = _0.document;

            function _204(_3, _50) {
                var _74 = _3.classList;
                if (_74 && _50) return _74.contains(_50);
                var _87 = _120(_3);
                return _87.indexOf(_50) !== -1
            }

            function _54(_3, _50) {
                var _74 = _3.classList;
                if (_74 && _50) {
                    _3.classList.add(_50);
                    return
                }
                var _87 = _120(_3);
                if (_87.indexOf(_50) === -1) _87.push(_50);
                _3.className = _87.join(' ')
            }

            function _30(_3, _50) {
                var _74 = _3.classList;
                if (_74 && _50) {
                    _3.classList.remove(_50);
                    return
                }
                var _87 = _120(_3);
                var _36 = _87.indexOf(_50);
                if (_36 !== -1) _87.splice(_36, 1);
                _3.className = _87.join(' ')
            }

            function _136(_3, _50, _238) {
                if (_238 === undefined) _238 = !_204(_3, _50);
                if (_238) {
                    _54(_3, _50)
                } else {
                    _30(_3, _50)
                }
            }

            function _120(_3) {
                var _320 = typeof _3.className === 'string' ? _3.className.replace(/\s+/g, ' ').trim() : '';
                return _320 !== '' ? _320.split(' ') : []
            }

            function _324() {
                return _170.max((_12.body || {}).scrollHeight || 0, (_12.body || {}).offsetHeight || 0, _12.documentElement.scrollHeight || 0, _12.documentElement.offsetHeight || 0, _12.documentElement.clientHeight || 0)
            }

            function _203() {
                var _115 = null;
                var _355 = _12.body.scrollHeight;
                _12.querySelectorAll('body *').forEach(function(_90) {
                    if (_90.tagName === 'LINKBAR-CONTAINER') return;
                    if (!_115) _115 = _90;
                    if (_115.scrollHeight < _90.scrollHeight) _115 = _90
                });
                return _115.scrollHeight > _355 ? _115 : null
            }

            function _251(_5) {
                if (!_5.autoScrollSelector) return _12.querySelector(_5.scrollSelector);
                return _203()
            }

            function _51(_165, _352) {
                var _68 = [];
                if (!_165) return _68;
                for (var _4 = 0; _4 < _165.length; _4++) {
                    if (_352(_165[_4], _4)) _68.push(_165[_4])
                }
                return _68
            }

            function _321(_299) {
                var _4 = Math.floor(Math.log(_299) / Math.log(1024));
                return (_299 / Math.pow(1024, _4)).toFixed(2) * 1 + ' ' + ['B', 'KB', 'MB', 'GB', 'TB'][_4]
            }

            function _318(_145) {
                var _166 = _145.length;
                while (_166) {
                    var _4 = _170.floor(_170.random() * _166--);
                    var _343 = _145[_166];
                    _145[_166] = _145[_4];
                    _145[_4] = _343
                }
            }

            function _80(_29) {
                if (!_29) return _29;
                return _29.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/'/g, '&#39;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
            }

            function _193(_29) {
                if (!_29) return _29;
                return _29.replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>')
            }

            function _208(url) {
                return /^https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_+.~#?&//=]*)$/.test(url.trim())
            }

            function _306(_29) {
                return _29.replace(/\[([^\]]+)\]\(([^)]+)\)/g, function(_55, _388, _31) {
                    _31 = _193(_31);
                    return _208(_31) ? '<a href="' + _31 + '" target="_blank">' + _388 + '</a>' : _55
                })
            }

            function _95(_8) {
                if (!_8) return _8;
                return _8.replace(/([^a-zA-Z\d-_])/g, '\\$1').replace(/^(-)?(\d)/, '$1\\3$2 ')
            }

            function _186(_8) {
                return _8 ? _244.parse(_8) : undefined
            }

            function _156(_8) {
                var _68;
                if (Array.prototype.toJSON) {
                    var _389 = Array.prototype.toJSON;
                    delete Array.prototype.toJSON;
                    _68 = _244.stringify(_8);
                    Array.prototype.toJSON = _389
                } else if (_8) {
                    _68 = _244.stringify(_8)
                }
                return _68
            }

            function _300(_437, _430) {
                var _126 = _187(_437);
                var _29 = _187(_430);
                var _404 = _170.max(_126.length, _29.length);
                if (_29 == 'NaN' || _126 == 'NaN') {
                    return false
                }
                for (var _4 = 0; _4 < _404; _4++) {
                    _126[_4] = _126[_4] || 0;
                    _29[_4] = _29[_4] || 0;
                    if (_126[_4] == _29[_4]) {
                        continue
                    }
                    return _126[_4] > _29[_4]
                }
                return true
            }

            function _187(_349) {
                var _279 = _349.split('.');
                var _317 = [];
                for (var _4 = 0; _4 < _279.length; _4++) {
                    _317.push(parseInt(_279[_4]))
                }
                return _317
            }

            function _297(_29, _457) {
                var _68 = _29;
                while (_68[_68.length - 1] === (_457 || ' ')) _68 = _68.slice(0, -1);
                return _68
            }

            function _328(_337) {
                var _55;
                var _75 = /([^?&=]+)(?:=([^&]*))?/g;
                var _315 = {};
                while ((_55 = _75.exec(_337)) !== null) {
                    var _11 = _55[1];
                    var _8 = _55[2] ? window.decodeURIComponent(_55[2].replace(/\+/g, ' ')) : null;
                    _315[_11] = _8
                }
                return _315
            }
            const platformRegexes = [{
                family: 'windows',
                regex: [/microsoft (windows) (vista|xp)/i, /(windows) nt 6\.2; (arm)/i, /(windows (?:phone(?: os)?|mobile))[/]?([\d.\w]*)/i, /(windows)[/]?([ntce\d.]+\w)(?!.+xbox)/i, /(win(?=3|9|n)|win 9x )([nt\d.]+)/i]
            }, {
                family: 'ios',
                regex: [/ip[honead]{2,4}\b(?:.*os ([\w]+) like mac|; opera)/i, /(?:ios;fbsv\/|iphone.+ios[/])([\d.]+)/i, /cfnetwork\/.+darwin/i]
            }, {
                family: 'macos',
                regex: [/(mac os x) ?([\w. ]*)/i, /(macintosh|mac_powerpc\b)(?!.+haiku)/i]
            }, {
                family: 'android',
                regex: [/droid ([\w.]+)\b.+android[- ]x86/i, /(android)[-/]?([\w.]*)/i]
            }, {
                family: 'linux',
                regex: [/\b(joli|palm)\b ?(?:os)?\/?([\w.]*)/i, /(mint)[/()]?(\w*)/i, /(mageia|vectorlinux)[; ]/i, /([kxln]?ubuntu|debian|suse|opensuse|gentoo|arch(?= linux)|slackware|fedora|mandriva|centos|pclinuxos|red ?hat|zenwalk|linpus|raspbian|plan 9|minix|risc os|contiki|deepin|manjaro|elementary os|sabayon|linspire)(?: gnu\/linux)?(?: enterprise)?(?:[- ]linux)?(?:-gnu)?[-/]?(?!chrom|package)([-\w.]*)/i, /(hurd|linux) ?([\w.]*)/i, /(gnu) ?([\w.]*)/i, /\b([-frentopcghs]{0,5}bsd|dragonfly)[/]?(?!amd|[ix346]{1,2}86)([\w.]*)/i, /(haiku) (\w+)/i]
            }];
            const browserRegexes = [{
                browser: 'chrome',
                regex: [/\b(?:crmo|crios)\/([\w.]+)/i]
            }, {
                browser: 'edge',
                regex: [/edg(?:e|ios|a)?\/([\w.]+)/i]
            }, {
                browser: 'opera',
                regex: [/(opera mini)\/([-\w.]+)/i, /(opera [mobiletab]{3,6})\b.+version\/([-\w.]+)/i, /(opera)(?:.+version\/|[/]+)([\w.]+)/i, /opios[/]+([\w.]+)/i, /\bopr\/([\w.]+)/i]
            }, {
                browser: 'ie',
                regex: [/(?:ms|\()(ie) ([\w.]+)/i, /trident.+rv[: ]([\w.]{1,9})\b.+like gecko/i]
            }, {
                browser: 'firefox',
                regex: [/\bfocus\/([\w.]+)/i, /fxios\/([\w.-]+)/i, /(?:mobile|tablet);.*(firefox)\/([\w.-]+)/i, /mobile vr; rv:([\w.]+)\).+firefox/i, /(firefox)\/([\w.]+)/i]
            }, {
                browser: 'opera',
                regex: [/\bopt\/([\w.]+)/i, /coast\/([\w.]+)/i]
            }, {
                browser: 'samsung',
                regex: [/(samsung)browser\/([\w.]+)/i]
            }, {
                browser: 'chrome',
                regex: [/ wv\).+(chrome)\/([\w.]+)/i, /chrome\/([\w.]+) mobile/i, /(chrome)\/v?([\w.]+)/i]
            }, {
                browser: 'android',
                regex: [/droid.+ version\/([\w.]+)\b.+(?:mobile safari|safari)/i]
            }, {
                browser: 'safari',
                regex: [/version\/([\w.,]+) .*mobile(?:\/\w+ | ?)safari/i, /iphone .*mobile(?:\/\w+ | ?)safari/i, /version\/([\w.,]+) .*(safari)/i, /webkit.+?(mobile ?safari|safari)(\/[\w.]+)/i]
            }];

            function _319(_296) {
                var _311;
                var _308;
                for (let _4 = 0; _4 < platformRegexes.length; _4++) {
                    var _304 = platformRegexes[_4];
                    let _55 = _304.regex.find(function(_229) {
                        return _229.test(_296)
                    });
                    if (_55) {
                        _308 = _304.family;
                        break
                    }
                }
                for (let _4 = 0; _4 < browserRegexes.length; _4++) {
                    var _310 = browserRegexes[_4];
                    let _55 = _310.regex.find(function(_229) {
                        return _229.test(_296)
                    });
                    if (_55) {
                        _311 = _310.browser;
                        break
                    }
                }
                return {
                    browser: _311,
                    os: _308
                }
            }

            function _42(_3, _2) {
                if (_3.nodeType !== 1) return false;
                if (_3.msMatchesSelector) return _3.msMatchesSelector(_2);
                if (_3.matches) return _3.matches(_2);
                return false
            }

            function _214(_90, _329) {
                var _79 = _41._266(_90);
                return _79 && _79.hasAttribute && _79.hasAttribute(_329)
            }

            function _192(ipaddress) {
                if (/^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/.test(ipaddress)) {
                    return (true)
                }
                return (false)
            }

            function _199(_29, _5) {
                if (_192(_29.hostname) || !_5.includeSubDomains) return _29.hostname;
                var _62 = _29.href;
                var _342 = /\.co\.|\.com\.|\.ac\.|\.org\.|\.gov\.|\.edu\.|\.net\./;
                _62 = _62.replace(/^http(s)?:\/\/?/i, '').replace(/^([^/]+)\/.*/i, '$1').replace(/:[\d]*$/, '');
                if (_342.test(_62)) _62 = _62.replace(/^([^.]+\.){1,}([^.]+\.[^.]+\.[^.]+)$/i, '$2');
                else _62 = _62.replace(/^([^.]+\.){1,}([^.]+\.[^.]+)$/i, '$2');
                return '.' + _62
            }
            this._199 = _199;
            this._192 = _192;
            this._204 = _204;
            this._54 = _54;
            this._30 = _30;
            this._136 = _136;
            this._120 = _120;
            this._324 = _324;
            this._51 = _51;
            this._321 = _321;
            this._318 = _318;
            this._80 = _80;
            this._193 = _193;
            this._208 = _208;
            this._306 = _306;
            this._95 = _95;
            this._186 = _186;
            this._156 = _156;
            this._300 = _300;
            this._187 = _187;
            this._297 = _297;
            this._42 = _42;
            this._214 = _214;
            this._328 = _328;
            this._319 = _319;
            this._203 = _203;
            this._251 = _251
        }

        function _419(_0) {
            var _253;
            this.proxyPushState = function(callback) {
                var _211 = _0.history;
                _253 = _211.pushState;
                _211.pushState = function() {
                    _0.setTimeout(callback, 100);
                    return _253.apply(_211, arguments)
                };
                _0.addEventListener('popstate', function() {
                    _0.setTimeout(callback, 100)
                })
            }
        }

        function _422(_0, _7) {
            const _440 = _0.Object;
            let _190;
            let _99, _188, _48, _96;
            this._117 = function(_118) {
                _99 = _118;
                _188 = _118.document;
                _48 = {}
            };
            this._117(_0);
            this._215 = function(_20) {
                const _127 = _99[_20];
                const _254 = `function ${_20}() { [native code] }`;
                let _21 = _127;
                try {
                    while (_48[_20] === undefined) {
                        if (!_21) {
                            _48[_20] = _224(_20);
                            break
                        } else if (_185(_21) === _254) {
                            _48[_20] = _21;
                            break
                        } else if (_185(_21.prototype ? .constructor) === _254) {
                            _48[_20] = _21.prototype.constructor;
                            break
                        } else {
                            _21 = Object.getPrototypeOf(_21)
                        }
                    }
                } catch (e) {
                    _7(e)
                }
                return _48[_20] ? ? _127
            };
            this._391 = function(_20, _102) {
                const _127 = _99[_20];
                const _423 = `function ${_102}() { [native code] }`;
                const _105 = `${_20}.${_102}`;
                try {
                    if (_48[_105] === undefined) {
                        let _21 = this._215(_20).prototype;
                        let _155 = _21[_102];
                        if (_185(_155) !== _423) {
                            _48[_20] = _224(_20);
                            _21 = _48[_20].prototype;
                            _155 = _21[_102]
                        }
                        _48[_105] = _155
                    }
                } catch (e) {
                    _7(e)
                }
                return _48[_105] ? ? _127[_102]
            };
            this._147 = function(_20, _106, _104) {
                const _127 = _99[_20];
                const _425 = `function ${_104} ${_106}() { [native code] }`;
                const _105 = `${_20}.${_106}.${_104}`;
                try {
                    if (_48[_105] === undefined) {
                        let _21 = this._215(_20).prototype;
                        let _189 = _220(_21, _106, _104);
                        if (_185(_189) !== _425) {
                            _48[_20] = _224(_20);
                            _21 = _48[_20].prototype;
                            _189 = _220(_21, _106, _104) ? ? _189
                        }
                        _48[_105] = _189
                    }
                } catch (e) {
                    _7(e)
                }
                return _48[_105] ? ? _220(_127, _106, _104)
            };

            function _220(_21, _106, _104) {
                return Object.getOwnPropertyDescriptor(_21, _106)[_104]
            }
            this._196 = function(_20, _102, _394) {
                const _155 = this._391(_20, _102);
                const _396 = Array.from(arguments).slice(3);
                return _155.apply(_394, _396)
            };
            this._223 = function(_66, _401) {
                this._196('CustomElementRegistry', 'define', _99.customElements, _66, _401)
            };
            this._402 = function(_66) {
                return this._196('CustomElementRegistry', 'get', _99.customElements, _66)
            };

            function _224(_20) {
                if (!_96) {
                    _96 = _188.createElement('iframe');
                    _96.style.display = 'none';
                    _96.style.width = '0';
                    _96.style.height = '0';
                    _96.style.position = 'absolute';
                    _188.body.appendChild(_96)
                }
                const _21 = _96.contentWindow[_20];
                return _21
            }

            function _185(_8) {
                return _8 ? .toString().replace(/\s+/g, ' ')
            }
            this._266 = function(_3) {
                const _456 = this._147('Node', 'parentNode', 'get');
                return _3 ? _456.apply(_3) : null
            };
            this._459 = function(_3) {
                const _446 = this._147('Node', 'nextSibling', 'get');
                return _3 ? _446.apply(_3) : null
            };
            this._453 = function(_3) {
                const _429 = this._147('Node', 'firstChild', 'get');
                return _3 ? _429.apply(_3) : null
            };
            this._482 = function(_3) {
                const _431 = this._147('Node', 'childNodes', 'get');
                return _3 ? _431.apply(_3) ? ? [] : []
            };
            this._483 = function(_3) {
                const _434 = this._147('Node', 'parentElement', 'get');
                return _3 ? _434.apply(_3) : null
            };
            this._484 = function(_3) {
                return this._196('Node', 'getRootNode', _3)
            };
            this._485 = function(_3) {
                if (!_3) return false;
                if (_190 === undefined) {
                    try {
                        _190 = _188.createElement('div').attachShadow({
                            mode: 'open'
                        }).constructor
                    } catch {
                        _190 = _99.ShadowRoot
                    }
                }
                let _21 = _3;
                let _8 = null;
                while (_8 === null) {
                    _21 = _440.getPrototypeOf(_21);
                    if (!_21 || _21.constructor === _99.DocumentFragment) _8 = false;
                    if (_21 && _21.constructor === _190) _8 = true
                }
                return _8
            }
        }
        var _128 = new _333(window, _6, _5, _7);
        var _59 = new _338(window, _41);
        var _69 = new _340(_5, _227, _230);
        var _292 = (typeof _347 === 'function') ? new _347(_5, _6) : {
            _491: function() {}
        };
        var _363 = (typeof _344 === 'function') ? new _344(window, _5, _59, _44, _6, _292, _13, _34, _7, _69) : {
            _37: function() {},
            _64: function() {},
            _354: function() {},
            _492: function() {},
            _494: function() {},
            _495: function() {}
        };
        var _365 = (typeof _335 === 'function') ? new _335(_41, _5) : {
            _498: function() {}
        };
        var _259 = new _351(window, _59, _41, _44, _6, _13, _34, _5);
        var _164 = _5.liveHeatmapsV3Enabled ? new _383(window, _5, _59, _6, _13, _69, _34) : new _369(window, _5, _59, _6, _13, _69, _34);
        var _256 = new _368(window, _59, _44, _6, _13, _5, _69);
        var _22 = _217 ? new _367(window, Math, _41, _5, _44, _6, _13, _69, _292, _34, _143, _363, _365, _7, _274, _445, _128) : null;
        _128._129();
        var _23 = false;
        if (_5.privacyToolEnabled) {
            _259._37(_18, _5._65, _5._148, _5._231, _5._232, _5._233, _7)
        } else if (_5.liveHeatmapsEnabled) {
            var _93;
            if (_5.taggerToolEnabled) {
                _93 = function(_78) {
                    _256._37(_7, _18, true, _78)
                }
            }
            _164._37(_5._65, _7, _18, _93)
        } else if (_5.taggerToolEnabled) {
            _256._37(_7, _18)
        } else if (_217) {
            _22._466();
            _23 = true
        }

        function _57() {
            return undefined
        }

        function _139() {
            return null
        }

        function _307() {
            return false
        }
        window.mouseflow = {
            start: _23 ? _22._37 : _57,
            stop: _23 ? _22._64 : function() {
                if (_5.privacyToolEnabled) _259._64();
                else if (_5.liveHeatmapsEnabled) _164._64()
            },
            newPageView: _23 ? _22._464 : function(_191, _60) {
                _5._248(_191, _60);
                if (_5.liveHeatmapsEnabled) _164._219()
            },
            stopSession: _23 ? _22._476 : _57,
            getSessionId: _23 ? _22._461 : _139,
            getPageViewId: _23 ? _22._462 : _139,
            tag: _23 ? _22._486 : _57,
            star: _23 ? _22._500 : _57,
            setVariable: _23 ? _22._499 : _57,
            identify: _23 ? _22._489 : _57,
            formSubmitAttempt: _23 ? _22._501 : _57,
            formSubmitSuccess: _23 ? _22._487 : _57,
            formSubmitFailure: _23 ? _22._478 : _57,
            addFriction: _23 ? _22._473 : _57,
            isRecording: _23 ? _22._488 : _307,
            isReturningUser: _23 ? _22._493 : _307,
            activateFeedback: _23 ? _22._354 : _57,
            proxyAttachShadow: _23 ? _22._465 : _57,
            recordingRate: _23 ? _22._469 : _139,
            version: _23 ? _22._460 : _139,
            lastUpdate: _23 ? _22._472 : _139,
            isCreditCard: _23 ? _22._481 : _57,
            pageNotFound: _23 ? _22._502 : _57,
            websiteId: _5._65,
            gdprEnabled: _5.gdprEnabled,
            updateHeatmap: _164._219,
            getDisplayUrl: _69._131,
            config: function() {
                return arguments.length === 1 ? _5[arguments[0]] : _5._174.apply(_5, arguments)
            },
            logConfig: function() {
                if (_5.debug) console.log(_5)
            },
            debug: function() {
                _5.debug = !_5.debug;
                console.log('MF: Debugging ' + (_5.debug ? 'enabled' : 'disabled'))
            },
            createTreeMirrorClient: _217 ? _22._480 : _57,
            exclude: function(selector) {
                if (!_5._148.includes(selector)) _5._148.push(selector)
            }
        };
        if (_5.enableSpa) _274.proxyPushState(window.mouseflow.newPageView);
        if (!_23) _128._37()
    })()
}